-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 10, 2021 at 10:10 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.3.16

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `immigrat_immigratly_fastzone`
--

-- --------------------------------------------------------

--
-- Table structure for table `assessment_case`
--

DROP TABLE IF EXISTS `assessment_case`;
CREATE TABLE `assessment_case` (
  `id` int(11) NOT NULL,
  `client_id` bigint(20) NOT NULL,
  `assessment_id` bigint(20) NOT NULL,
  `case_id` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assessment_case`
--

INSERT INTO `assessment_case` (`id`, `client_id`, `assessment_id`, `case_id`, `created_at`, `updated_at`) VALUES
(1, 9218036547, 5264897311, 9478352116, '2021-02-10 16:23:54', '2021-02-10 16:35:06');

-- --------------------------------------------------------

--
-- Table structure for table `assign_leads`
--

DROP TABLE IF EXISTS `assign_leads`;
CREATE TABLE `assign_leads` (
  `id` bigint(11) NOT NULL,
  `leads_id` varchar(500) NOT NULL,
  `user_id` varchar(500) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assign_leads`
--

INSERT INTO `assign_leads` (`id`, `leads_id`, `user_id`, `created_at`, `updated_at`) VALUES
(39, '6975321480', '7659124831', '2021-01-22 12:06:42', '2021-01-22 12:06:42'),
(40, '5263187409', '7659124831', '2021-01-24 14:17:46', '2021-01-24 14:17:46'),
(41, '5263187409', '7452316819', '2021-01-24 14:17:46', '2021-01-24 14:17:46'),
(42, '3182546791', '7659124831', '2021-01-24 14:25:50', '2021-01-24 14:25:50'),
(43, '3182546791', '7136582914', '2021-01-24 14:25:50', '2021-01-24 14:25:50');

-- --------------------------------------------------------

--
-- Table structure for table `cases`
--

DROP TABLE IF EXISTS `cases`;
CREATE TABLE `cases` (
  `id` int(11) NOT NULL,
  `unique_id` bigint(20) NOT NULL,
  `client_id` bigint(20) NOT NULL,
  `case_title` varchar(500) NOT NULL,
  `description` text,
  `start_date` varchar(20) DEFAULT NULL,
  `end_date` varchar(20) DEFAULT NULL,
  `visa_service_id` bigint(20) NOT NULL,
  `pinned_folders` text,
  `status` int(11) NOT NULL DEFAULT '0',
  `created_by` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cases`
--

INSERT INTO `cases` (`id`, `unique_id`, `client_id`, `case_title`, `description`, `start_date`, `end_date`, `visa_service_id`, `pinned_folders`, `status`, `created_by`, `created_at`, `updated_at`) VALUES
(2, 3724859016, 7829, 'Ashit Charlie case for Employment Visa Edited', '<p>sfdgdsgfdgdfgdfgf gfdgfdgdfgdfgdfgdfgdfgdfgdf</p>', '25/11/2020', '26/02/2021', 1207953846, NULL, 0, 8911642537, '2020-11-14 14:59:05', '2020-12-30 15:07:17'),
(6, 4815302697, 81306, 'Daniel Homes case for Employment Visa', NULL, '16/11/2020', NULL, 1207953846, '{\"default\":[\"63724\"]}', 0, 8911642537, '2020-11-16 06:59:20', '2020-12-30 15:06:41'),
(7, 4161739825, 70532, 'Cherry Pick case for Visitor Visa', NULL, '05/12/2020', '09/01/2021', 1207953846, NULL, 0, 8911642537, '2020-12-06 15:36:03', '2020-12-11 16:26:23'),
(8, 1361742985, 5641718923, 'Dk Dev Case for work permit', NULL, '21/01/2021', '26/01/2021', 6510423798, NULL, 0, 8911642537, '2021-01-21 16:38:16', '2021-01-21 16:38:16'),
(9, 3524968117, 9218036547, 'Lead DK for Travaler Visa', NULL, '01/01/2021', '22/01/2021', 6518273409, NULL, 0, 8911642537, '2021-01-21 17:11:50', '2021-01-21 17:11:50'),
(10, 1961485732, 9218036547, 'Dk Dev Case for Employement', '<p>Dk Dev Case for EmployementDk Dev Case for EmployementDk Dev Case for EmployementDk Dev Case for EmployementDk Dev Case for EmployementDk Dev Case for EmployementDk Dev Case for EmployementDk Dev Case for EmployementDk Dev Case for EmployementDk Dev Case for EmployementDk Dev Case for EmployementDk Dev Case for EmployementDk Dev Case for EmployementDk Dev Case for EmployementDk Dev Case for EmployementDk Dev Case for Employement</p>', '04/02/2021', '03/03/2021', 3251864709, NULL, 0, 8911642537, '2021-01-22 16:20:45', '2021-01-22 16:20:45'),
(11, 6971385214, 9218036547, 'Testing Assessment', NULL, NULL, NULL, 8435910276, NULL, 0, 0, '2021-02-10 16:23:54', '2021-02-10 16:23:54');

-- --------------------------------------------------------

--
-- Table structure for table `case_documents`
--

DROP TABLE IF EXISTS `case_documents`;
CREATE TABLE `case_documents` (
  `id` int(11) NOT NULL,
  `unique_id` bigint(20) NOT NULL,
  `case_id` bigint(20) NOT NULL,
  `folder_id` bigint(20) NOT NULL,
  `file_id` bigint(20) NOT NULL,
  `document_type` varchar(100) NOT NULL,
  `added_by` varchar(100) DEFAULT NULL,
  `created_by` bigint(20) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `case_documents`
--

INSERT INTO `case_documents` (`id`, `unique_id`, `case_id`, `folder_id`, `file_id`, `document_type`, `added_by`, `created_by`, `created_at`, `updated_at`) VALUES
(3, 4573960812, 2147483647, 321589, 8942605713, 'extra', 'admin', 1, '2020-11-20 16:10:31', '2020-11-21 17:13:47'),
(4, 2358706914, 2147483647, 61379, 1376490528, 'default', 'admin', 1, '2020-11-20 16:58:45', '2020-11-24 15:16:17'),
(5, 9703456218, 2147483647, 321589, 2679384051, 'extra', 'admin', 1, '2020-11-20 16:58:46', '2020-11-24 15:15:54'),
(6, 2765913480, 2147483647, 249015, 5237108694, 'other', 'admin', 1, '2020-11-20 16:59:06', '2020-11-23 06:18:36'),
(7, 6931580724, 2147483647, 91387, 1978560234, 'default', 'admin', 1, '2020-11-20 17:05:44', '2020-11-24 15:16:01'),
(8, 7451630298, 2147483647, 249015, 1398405267, 'other', 'admin', 1, '2020-11-20 17:05:44', '2020-11-23 06:33:58'),
(9, 9273851406, 2147483647, 321589, 9684201357, 'extra', 'admin', 1, '2020-11-20 17:05:45', '2020-11-24 15:16:10'),
(10, 658927314, 2147483647, 91387, 273954618, 'default', 'admin', 12, '2020-11-28 16:55:22', '2020-11-28 16:55:22'),
(11, 6938154702, 4532907168, 91387, 7538246091, 'default', 'admin', 12, '2020-11-28 17:09:46', '2020-11-28 17:09:46'),
(12, 5746213809, 4532907168, 63724, 935812674, 'default', 'admin', 12, '2020-11-28 17:18:36', '2020-11-29 16:19:21'),
(13, 5714236089, 4532907168, 95324, 526139478, 'default', 'admin', 12, '2020-11-28 17:18:37', '2020-11-29 16:19:30'),
(14, 4302596817, 4532907168, 91387, 2085974316, 'default', 'admin', 12, '2020-11-28 17:18:38', '2020-11-28 17:18:38'),
(15, 1056827943, 4532907168, 61379, 617543982, 'default', 'admin', 12, '2020-11-29 14:35:09', '2020-11-29 14:35:09'),
(16, 8294706315, 4532907168, 61379, 2187463059, 'default', 'admin', 12, '2020-11-29 14:35:10', '2020-11-30 06:41:09'),
(17, 2690174853, 4532907168, 249015, 2678130954, 'other', 'admin', 12, '2020-11-29 15:16:17', '2020-11-29 15:16:17'),
(18, 5926734810, 4532907168, 249015, 148593762, 'other', 'admin', 12, '2020-11-29 15:16:19', '2020-11-29 15:16:19'),
(19, 5940827361, 4815302697, 63724, 8690415327, 'default', 'admin', 1, '2020-12-01 13:53:50', '2020-12-01 13:53:50'),
(20, 7418625390, 4815302697, 63724, 7915463082, 'default', 'admin', 1, '2020-12-01 13:53:50', '2020-12-01 13:53:50'),
(21, 2160958347, 4815302697, 63724, 1970534628, 'default', 'admin', 1, '2020-12-01 13:53:51', '2020-12-01 13:53:51'),
(38, 1728956430, 4532907168, 63724, 6894327510, 'default', 'client', 70532, '2020-12-02 15:02:00', '2020-12-02 15:02:00'),
(40, 5124678903, 4532907168, 61379, 5429180376, 'default', 'client', 70532, '2020-12-02 15:08:06', '2020-12-02 15:08:06'),
(41, 8215069743, 4532907168, 63724, 4509137682, 'default', NULL, 12, '2020-12-02 15:32:29', '2020-12-02 15:32:29'),
(42, 5469123087, 4532907168, 63724, 4051876932, 'default', NULL, 12, '2020-12-02 15:34:40', '2020-12-02 15:34:40'),
(43, 8092431657, 4532907168, 63724, 1580697342, 'default', NULL, 12, '2020-12-02 15:36:00', '2020-12-02 15:36:00'),
(44, 3128716945, 4532907168, 63724, 3570812496, 'default', 'client', 70532, '2020-12-03 16:28:50', '2020-12-03 16:28:50'),
(45, 5168291437, 3724859016, 63724, 6591784132, 'default', 'admin', 1, '2020-12-06 13:51:42', '2020-12-06 13:51:42'),
(46, 1964713285, 4532907168, 61379, 1953718246, 'default', 'client', 70532, '2020-12-06 15:55:35', '2020-12-06 15:55:35'),
(48, 8791325416, 4532907168, 63724, 7094531862, 'default', 'client', 70532, '2020-12-06 15:55:54', '2020-12-06 15:55:54'),
(49, 4681753192, 4161739825, 2351918746, 5321617948, 'extra', 'admin', 1, '2020-12-09 15:53:08', '2020-12-09 15:53:08'),
(50, 5318126749, 4161739825, 2351918746, 9341726581, 'extra', 'admin', 1, '2020-12-09 15:53:09', '2020-12-09 15:53:09'),
(51, 8692473115, 4161739825, 2351918746, 8431159267, 'extra', 'admin', 1, '2020-12-09 15:53:10', '2020-12-09 15:53:10'),
(52, 1536471982, 4161739825, 61379, 7523411968, 'default', 'admin', 1, '2020-12-31 16:36:03', '2021-01-21 16:27:52'),
(53, 9128314657, 4161739825, 63724, 1319857462, 'default', 'admin', 1, '2020-12-31 16:36:03', '2020-12-31 16:36:03'),
(54, 1483561792, 4161739825, 91387, 1645237891, 'default', 'admin', 1, '2020-12-31 16:36:03', '2021-01-21 16:27:55'),
(55, 4317256918, 4161739825, 2351918746, 2179638541, 'extra', NULL, 12, '2021-01-21 14:28:11', '2021-01-21 14:28:11'),
(56, 1186294753, 4161739825, 2351918746, 4193867215, 'extra', NULL, 12, '2021-01-21 14:28:12', '2021-01-21 14:28:12'),
(57, 5117842639, 4161739825, 2351918746, 5731142986, 'extra', NULL, 12, '2021-01-21 14:28:38', '2021-01-21 14:28:38'),
(58, 8516347192, 4161739825, 2351918746, 3864127195, 'extra', NULL, 12, '2021-01-21 14:30:31', '2021-01-21 14:30:31'),
(59, 5631278149, 4161739825, 2351918746, 6915437812, 'extra', NULL, 12, '2021-01-21 14:31:10', '2021-01-21 14:31:10'),
(60, 2416317958, 4161739825, 95324, 1726458319, 'default', NULL, 12, '2021-01-21 14:56:05', '2021-01-21 16:28:02'),
(64, 6711398452, 3524968117, 95324, 5483791261, 'default', 'client', 9218036547, '2021-01-27 16:27:02', '2021-01-27 16:27:02'),
(65, 4895671213, 3524968117, 95324, 9576213184, 'default', 'client', 9218036547, '2021-01-27 16:27:04', '2021-01-27 16:27:04'),
(71, 7491823561, 3524968117, 95324, 7815469132, 'default', 'client', 9218036547, '2021-01-31 16:29:24', '2021-01-31 16:29:24'),
(72, 4597213681, 3524968117, 95324, 1847361952, 'default', 'client', 9218036547, '2021-01-31 16:29:26', '2021-01-31 16:29:26'),
(73, 1756984231, 6971385214, 61379, 7138612945, 'default', 'client', 0, '2021-02-10 16:23:54', '2021-02-10 16:23:54'),
(74, 5396817412, 6971385214, 61379, 5391826741, 'default', 'client', 0, '2021-02-10 16:23:55', '2021-02-10 16:23:55'),
(75, 4653812971, 6971385214, 61379, 2146159387, 'default', 'client', 0, '2021-02-10 16:23:55', '2021-02-10 16:23:55'),
(76, 4957613182, 6971385214, 61379, 1716983254, 'default', 'client', 0, '2021-02-10 16:23:55', '2021-02-10 16:23:55'),
(77, 8675114293, 9478352116, 61379, 7138612945, 'default', 'client', 0, '2021-02-10 16:35:06', '2021-02-10 16:35:06'),
(78, 5418237916, 9478352116, 61379, 5391826741, 'default', 'client', 0, '2021-02-10 16:35:06', '2021-02-10 16:35:06'),
(79, 1945176238, 9478352116, 61379, 2146159387, 'default', 'client', 0, '2021-02-10 16:35:06', '2021-02-10 16:35:06'),
(80, 6451913278, 9478352116, 61379, 1716983254, 'default', 'client', 0, '2021-02-10 16:35:06', '2021-02-10 16:35:06');

-- --------------------------------------------------------

--
-- Table structure for table `case_folders`
--

DROP TABLE IF EXISTS `case_folders`;
CREATE TABLE `case_folders` (
  `id` int(11) NOT NULL,
  `case_id` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_by` int(11) NOT NULL,
  `unique_id` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `case_folders`
--

INSERT INTO `case_folders` (`id`, `case_id`, `name`, `created_by`, `unique_id`, `created_at`, `updated_at`) VALUES
(2, 2147483647, 'Marriage Certificate', 1, 321589, '2020-11-18 16:57:04', '2020-11-18 16:57:04'),
(4, 4161739825, 'Others', 1, 2351918746, '2020-12-09 15:51:31', '2020-12-09 15:51:31');

-- --------------------------------------------------------

--
-- Table structure for table `case_invoices`
--

DROP TABLE IF EXISTS `case_invoices`;
CREATE TABLE `case_invoices` (
  `id` int(11) NOT NULL,
  `unique_id` bigint(20) NOT NULL,
  `case_id` bigint(20) NOT NULL,
  `invoice_id` bigint(20) NOT NULL,
  `total_amount` decimal(11,2) NOT NULL,
  `notes` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `case_invoices`
--

INSERT INTO `case_invoices` (`id`, `unique_id`, `case_id`, `invoice_id`, `total_amount`, `notes`, `created_at`, `updated_at`) VALUES
(1, 3117925486, 4161739825, 8176329541, '400.00', NULL, '2020-12-16 13:48:35', '2020-12-16 13:48:35'),
(2, 2117948536, 4161739825, 1836125497, '150.00', NULL, '2020-12-18 16:18:03', '2020-12-18 16:18:03'),
(3, 5617832491, 4161739825, 4192731586, '400.00', 'test terst', '2020-12-19 15:35:32', '2020-12-19 15:35:32'),
(4, 7561389124, 4161739825, 2195431786, '610.00', NULL, '2020-12-25 16:30:19', '2020-12-25 16:30:19'),
(5, 2634185791, 4161739825, 7329518146, '44.00', NULL, '2020-12-25 16:57:24', '2020-12-25 16:57:24'),
(6, 4158273961, 4161739825, 3162859417, '44.00', NULL, '2020-12-25 16:57:33', '2020-12-25 16:57:33'),
(7, 2511947863, 4161739825, 9136574821, '44.00', NULL, '2020-12-25 17:00:26', '2020-12-25 17:00:26'),
(8, 6214159873, 3524968117, 4219316857, '350.00', NULL, '2021-01-22 16:12:43', '2021-01-22 16:13:36'),
(9, 4735121869, 1961485732, 8392751641, '500.00', NULL, '2021-01-22 16:50:41', '2021-01-22 16:50:41');

-- --------------------------------------------------------

--
-- Table structure for table `case_invoice_items`
--

DROP TABLE IF EXISTS `case_invoice_items`;
CREATE TABLE `case_invoice_items` (
  `id` int(11) NOT NULL,
  `unique_id` bigint(20) NOT NULL,
  `case_id` bigint(20) NOT NULL,
  `case_invoice_id` bigint(20) NOT NULL,
  `particular` varchar(500) NOT NULL,
  `amount` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `case_invoice_items`
--

INSERT INTO `case_invoice_items` (`id`, `unique_id`, `case_id`, `case_invoice_id`, `particular`, `amount`, `created_at`, `updated_at`) VALUES
(1, 1396158274, 4161739825, 3117925486, 'Initial Fees', 150, '2020-12-16 13:48:35', '2020-12-16 13:48:35'),
(2, 6279813514, 4161739825, 3117925486, 'Visa Processing Fees', 250, '2020-12-16 13:48:35', '2020-12-16 13:48:35'),
(3, 9237456118, 4161739825, 2117948536, 'Document Verification Fees', 150, '2020-12-18 16:18:03', '2020-12-18 16:18:03'),
(4, 6938514721, 4161739825, 5617832491, 'Initial Fees', 250, '2020-12-19 15:35:32', '2020-12-19 15:35:32'),
(5, 4578219136, 4161739825, 5617832491, 'Document Processing', 150, '2020-12-19 15:35:32', '2020-12-19 15:35:32'),
(6, 1238941657, 4161739825, 7561389124, 'test', 555, '2020-12-25 16:30:20', '2020-12-25 16:30:20'),
(7, 2741861395, 4161739825, 7561389124, 'gfgfg', 55, '2020-12-25 16:30:20', '2020-12-25 16:30:20'),
(8, 7131562984, 4161739825, 2634185791, 'cffsfdsf', 44, '2020-12-25 16:57:24', '2020-12-25 16:57:24'),
(9, 4239171685, 4161739825, 4158273961, 'cffsfdsf', 44, '2020-12-25 16:57:33', '2020-12-25 16:57:33'),
(10, 6137259814, 4161739825, 2511947863, 'cffsfdsf', 44, '2020-12-25 17:00:26', '2020-12-25 17:00:26'),
(11, 2431796158, 3524968117, 6214159873, 'Initial Payment', 350, '2021-01-22 16:12:43', '2021-01-22 16:12:43'),
(13, 6291874135, 1961485732, 4735121869, 'inital payment', 500, '2021-01-22 16:50:41', '2021-01-22 16:50:41');

-- --------------------------------------------------------

--
-- Table structure for table `case_teams`
--

DROP TABLE IF EXISTS `case_teams`;
CREATE TABLE `case_teams` (
  `id` int(11) NOT NULL,
  `unique_id` bigint(20) NOT NULL,
  `case_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `case_teams`
--

INSERT INTO `case_teams` (`id`, `unique_id`, `case_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 4783151296, 4161739825, 7659124831, '2020-12-08 15:19:17', '2020-12-08 15:19:17'),
(2, 7413815269, 4161739825, 7452316819, '2020-12-08 15:19:17', '2020-12-08 15:19:17'),
(3, 1216548397, 4815302697, 7452316819, '2020-12-30 15:06:41', '2020-12-30 15:06:41'),
(4, 5123719864, 3724859016, 7659124831, '2020-12-30 15:07:17', '2020-12-30 15:07:17'),
(5, 1846195237, 3724859016, 7452316819, '2020-12-30 15:12:42', '2020-12-30 15:12:42'),
(6, 4237169815, 1961485732, 7452316819, '2021-01-22 16:20:45', '2021-01-22 16:20:45');

-- --------------------------------------------------------

--
-- Table structure for table `chats`
--

DROP TABLE IF EXISTS `chats`;
CREATE TABLE `chats` (
  `id` int(11) NOT NULL,
  `case_id` bigint(20) NOT NULL DEFAULT '0',
  `message` text NOT NULL,
  `file_id` bigint(20) NOT NULL DEFAULT '0',
  `send_by` varchar(100) NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `type` varchar(20) NOT NULL,
  `chat_type` varchar(100) NOT NULL,
  `chat_client_id` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chats`
--

INSERT INTO `chats` (`id`, `case_id`, `message`, `file_id`, `send_by`, `created_by`, `type`, `chat_type`, `chat_client_id`, `created_at`, `updated_at`) VALUES
(1, 0, 'testing message', 0, 'client', 70532, 'text', 'general', 70532, '2020-12-07 08:41:24', '2020-12-07 08:41:24'),
(2, 0, 'Place this code, which contains everything you need, within the <head> of each template or page that you want to use Icon set on.', 0, 'client', 70532, 'text', 'general', 70532, '2020-12-07 08:47:19', '2020-12-07 08:47:19'),
(3, 0, 'Place this code, which contains everything', 0, 'client', 70532, 'text', 'general', 70532, '2020-12-07 08:48:19', '2020-12-07 08:48:19'),
(4, 0, 'dffdfd', 0, 'client', 70532, 'text', 'general', 70532, '2020-12-07 08:49:08', '2020-12-07 08:49:08'),
(5, 0, 'vcvcvc', 0, 'client', 70532, 'text', 'general', 70532, '2020-12-07 08:49:47', '2020-12-07 08:49:47'),
(6, 0, 'test test', 0, 'client', 70532, 'text', 'general', 70532, '2020-12-07 08:51:35', '2020-12-07 08:51:35'),
(7, 0, 'test case message', 0, 'client', 70532, 'text', 'general', 70532, '2020-12-07 08:53:06', '2020-12-07 08:53:06'),
(8, 0, 'new case message', 0, 'client', 70532, 'text', 'general', 70532, '2020-12-07 08:53:17', '2020-12-07 08:53:17'),
(9, 0, 'avatar3.png', 1935186274, 'client', 70532, 'file', 'general', 70532, '2020-12-07 09:04:42', '2020-12-07 09:04:42'),
(10, 0, 'tests', 0, 'admin', 8911642537, 'text', 'general', 70532, '2020-12-07 09:51:12', '2020-12-07 09:51:12'),
(11, 4161739825, 'user8-128x128.jpg', 1257489316, 'admin', 8911642537, 'file', 'general', 70532, '2020-12-08 14:00:56', '2020-12-08 14:00:56'),
(12, 0, 'test test5', 0, 'admin', 8911642537, 'text', 'general', 70532, '2020-12-08 14:05:03', '2020-12-08 14:05:03'),
(13, 0, 'vcvcvc vc cvc', 0, 'admin', 8911642537, 'text', 'general', 70532, '2020-12-08 14:05:54', '2020-12-08 14:05:54'),
(14, 0, 'test', 0, 'manager', 7659124831, 'text', 'general', 70532, '2020-12-08 16:26:02', '2020-12-08 16:26:02'),
(15, 0, 'vcvcv', 0, 'manager', 7659124831, 'text', 'general', 70532, '2020-12-08 16:26:06', '2020-12-08 16:26:06'),
(16, 4161739825, 'test test', 0, 'admin', 8911642537, 'text', 'case_chat', 70532, '2020-12-09 13:35:37', '2020-12-09 13:35:37'),
(17, 4161739825, 'fffsfdsf', 0, 'admin', 8911642537, 'text', 'case_chat', 70532, '2020-12-09 14:44:12', '2020-12-09 14:44:12'),
(18, 0, 'fdsffdfdf cvcvc vcvvc', 0, 'client', 70532, 'text', 'general', 70532, '2020-12-24 15:41:20', '2020-12-24 15:41:20'),
(19, 0, 'test notification', 0, 'client', 70532, 'text', 'general', 70532, '2020-12-24 16:03:04', '2020-12-24 16:03:04'),
(20, 0, 'test notification', 0, 'client', 70532, 'text', 'general', 70532, '2020-12-24 16:03:25', '2020-12-24 16:03:25'),
(21, 0, 'vvcvcvcvcvc', 0, 'client', 70532, 'text', 'general', 70532, '2020-12-24 16:07:15', '2020-12-24 16:07:15'),
(22, 0, 'vvcvcvcvcvc', 0, 'client', 70532, 'text', 'general', 70532, '2020-12-24 16:10:34', '2020-12-24 16:10:34'),
(23, 0, 'tefgfdgdfg', 0, 'client', 70532, 'text', 'general', 70532, '2020-12-24 16:11:42', '2020-12-24 16:11:42'),
(24, 0, 'vcbvcbcv gfgf  fdgfg', 0, 'client', 70532, 'text', 'case_chat', 70532, '2020-12-24 16:13:13', '2020-12-24 16:13:13'),
(25, 0, 'vcvcxcvcxv', 0, 'client', 70532, 'text', 'case_chat', 70532, '2020-12-24 16:17:36', '2020-12-24 16:17:36'),
(26, 0, 'vcxv vcxvxcvcx', 0, 'admin', 8911642537, 'text', 'general', 70532, '2020-12-28 05:08:54', '2020-12-28 05:08:54'),
(27, 0, 'cxvcxv  sfsfs sdfsdfds', 0, 'admin', 8911642537, 'text', 'general', 70532, '2020-12-28 05:19:09', '2020-12-28 05:19:09'),
(28, 0, 'cxvcxv  sfsfs sdfsdfds', 0, 'admin', 8911642537, 'text', 'general', 70532, '2020-12-28 05:20:09', '2020-12-28 05:20:09'),
(29, 4161739825, 'vccvc vccvvc', 0, 'admin', 8911642537, 'text', 'case_chat', 70532, '2020-12-28 05:20:28', '2020-12-28 05:20:28'),
(30, 4161739825, 'boxed-bg.jpg', 5481792136, 'admin', 8911642537, 'file', 'case_chat', 70532, '2020-12-28 05:20:38', '2020-12-28 05:20:38'),
(31, 4161739825, 'avatar2.png', 3629475811, 'admin', 8911642537, 'file', 'case_chat', 70532, '2020-12-28 05:46:47', '2020-12-28 05:46:47'),
(32, 4161739825, 'avatar.png', 3718146295, 'admin', 8911642537, 'file', 'case_chat', 70532, '2020-12-28 05:57:02', '2020-12-28 05:57:02'),
(33, 4161739825, 'photo2.png', 2836719514, 'admin', 8911642537, 'file', 'case_chat', 70532, '2020-12-28 05:59:02', '2020-12-28 05:59:02'),
(34, 0, 'cvcxvcv', 0, 'associate', 7452316819, 'text', 'general', 70532, '2020-12-30 16:36:27', '2020-12-30 16:36:27'),
(35, 0, 'cvcxvcv', 0, 'associate', 7452316819, 'text', 'general', 70532, '2020-12-30 16:36:34', '2020-12-30 16:36:34'),
(36, 0, 'cvcxvcv', 0, 'associate', 7452316819, 'text', 'general', 70532, '2020-12-30 16:37:22', '2020-12-30 16:37:22'),
(37, 4161739825, 'user2-160x160.jpg', 2157146398, 'associate', 7452316819, 'file', 'general', 70532, '2020-12-30 16:37:29', '2020-12-30 16:37:29'),
(38, 0, 'fdfdfd', 0, 'admin', 8911642537, 'text', 'general', 9218036547, '2021-01-22 16:21:00', '2021-01-22 16:21:00'),
(39, 1961485732, 'testing-17-10-2020.pdf', 4972368511, 'admin', 8911642537, 'file', 'general', 9218036547, '2021-01-22 16:21:23', '2021-01-22 16:21:23'),
(40, 1961485732, 'Android_Setup_document.pdf', 5641391827, 'admin', 8911642537, 'file', 'case_chat', 9218036547, '2021-01-22 16:21:37', '2021-01-22 16:21:37');

-- --------------------------------------------------------

--
-- Table structure for table `chat_read`
--

DROP TABLE IF EXISTS `chat_read`;
CREATE TABLE `chat_read` (
  `id` int(11) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `chat_id` int(11) NOT NULL,
  `chat_type` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
CREATE TABLE `countries` (
  `id` int(11) NOT NULL,
  `sortname` varchar(3) NOT NULL,
  `name` varchar(150) NOT NULL,
  `phonecode` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
CREATE TABLE `documents` (
  `id` int(11) NOT NULL,
  `original_name` varchar(100) NOT NULL,
  `file_name` varchar(500) NOT NULL,
  `unique_id` bigint(20) NOT NULL,
  `is_shared` int(11) NOT NULL DEFAULT '0',
  `shared_id` bigint(20) DEFAULT NULL,
  `created_by` bigint(20) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `documents`
--

INSERT INTO `documents` (`id`, `original_name`, `file_name`, `unique_id`, `is_shared`, `shared_id`, `created_by`, `created_at`, `updated_at`) VALUES
(1, '21_74_43.jpg', '1605859830.jpg', 8320154769, 0, NULL, 1, '2020-11-20 16:10:30', '2020-11-20 16:10:30'),
(2, '21_55_Vw_tourag.jpg', '1605859830.jpg', 5892630714, 0, NULL, 1, '2020-11-20 16:10:30', '2020-11-20 16:10:30'),
(3, 'berlingo.jpg', '1605859831.jpg', 8942605713, 0, NULL, 1, '2020-11-20 16:10:31', '2020-11-20 16:10:31'),
(4, 'Ford-Fiesta.jpg', '1605862725.jpg', 1376490528, 0, NULL, 1, '2020-11-20 16:58:45', '2020-11-20 16:58:45'),
(5, 'fridge-truck.jpg', '1605862726.jpg', 2679384051, 0, NULL, 1, '2020-11-20 16:58:46', '2020-11-20 16:58:46'),
(6, 'opel-combo.jpg', '1605862746.jpg', 5237108694, 0, NULL, 1, '2020-11-20 16:59:06', '2020-11-20 16:59:06'),
(7, 'citroen-c4-van-2.gif', '70589-citroen-c4-van-2.gif', 1978560234, 0, NULL, 1, '2020-11-20 17:05:44', '2020-11-20 17:05:44'),
(8, 'ford-fiesta-van.gif', '58062-ford-fiesta-van.gif', 1398405267, 0, NULL, 1, '2020-11-20 17:05:44', '2020-11-20 17:05:44'),
(9, 'ford-focus-van-2.gif', '53169-ford-focus-van-2.gif', 9684201357, 0, NULL, 1, '2020-11-20 17:05:45', '2020-11-20 17:05:45'),
(10, 'avatar.png', '18234-avatar.png', 5081793642, 0, NULL, 12, '2020-11-28 16:44:03', '2020-11-28 16:44:03'),
(11, 'avatar2.png', '39284-avatar2.png', 563489217, 0, NULL, 12, '2020-11-28 16:44:04', '2020-11-28 16:44:04'),
(12, 'avatar3.png', '80276-avatar3.png', 3968427510, 0, NULL, 12, '2020-11-28 16:44:05', '2020-11-28 16:44:05'),
(13, 'avatar4.png', '93712-avatar4.png', 8604213795, 0, NULL, 12, '2020-11-28 16:44:06', '2020-11-28 16:44:06'),
(14, 'avatar4.png', '68130-avatar4.png', 461237589, 0, NULL, 12, '2020-11-28 16:46:34', '2020-11-28 16:46:34'),
(15, 'prod-1.jpg', '84902-prod-1.jpg', 9672540381, 0, NULL, 12, '2020-11-28 16:47:22', '2020-11-28 16:47:22'),
(16, 'mastercard.png', '08751-mastercard.png', 9876352104, 0, NULL, 12, '2020-11-28 16:51:14', '2020-11-28 16:51:14'),
(17, 'photo4.jpg', '01786-photo4.jpg', 3201745869, 0, NULL, 12, '2020-11-28 16:54:13', '2020-11-28 16:54:13'),
(18, 'photo2.png', '20354-photo2.png', 273954618, 0, NULL, 12, '2020-11-28 16:55:22', '2020-11-28 16:55:22'),
(19, 'avatar.png', '57318-avatar.png', 2301845967, 0, NULL, 12, '2020-11-28 17:07:25', '2020-11-28 17:07:25'),
(20, 'avatar3.png', '20895-avatar3.png', 1275380496, 0, NULL, 12, '2020-11-28 17:07:26', '2020-11-28 17:07:26'),
(21, 'avatar.png', '15280-avatar.png', 2137948065, 0, NULL, 12, '2020-11-28 17:08:45', '2020-11-28 17:08:45'),
(22, 'avatar.png', '78563-avatar.png', 7538246091, 0, NULL, 12, '2020-11-28 17:09:46', '2020-11-28 17:09:46'),
(23, 'boxed-bg.png', '46937-boxed-bg.png', 935812674, 0, NULL, 12, '2020-11-28 17:18:36', '2020-11-28 17:18:36'),
(24, 'boxed-bg.jpg', '69804-boxed-bg.jpg', 526139478, 0, NULL, 12, '2020-11-28 17:18:37', '2020-11-28 17:18:37'),
(25, 'default-150x150.png', '24610-default-150x150.png', 2085974316, 0, NULL, 12, '2020-11-28 17:18:38', '2020-11-28 17:18:38'),
(26, 'photo2.png', '14683-photo2.png', 617543982, 0, NULL, 12, '2020-11-29 14:35:09', '2020-11-29 14:35:09'),
(27, 'photo4.jpg', '24136-photo4.jpg', 2187463059, 0, NULL, 12, '2020-11-29 14:35:10', '2020-11-29 14:35:10'),
(28, 'user2-160x160.jpg', '89147-user2-160x160.jpg', 2678130954, 0, NULL, 12, '2020-11-29 15:16:17', '2020-11-29 15:16:17'),
(29, 'user1-128x128.jpg', '71054-user1-128x128.jpg', 148593762, 0, NULL, 12, '2020-11-29 15:16:19', '2020-11-29 15:16:19'),
(30, 'avatar.png', '81705-avatar.png', 8690415327, 0, NULL, 1, '2020-12-01 13:53:49', '2020-12-01 13:53:49'),
(31, 'avatar2.png', '63798-avatar2.png', 7915463082, 0, NULL, 1, '2020-12-01 13:53:50', '2020-12-01 13:53:50'),
(32, 'avatar4.png', '82590-avatar4.png', 1970534628, 0, NULL, 1, '2020-12-01 13:53:51', '2020-12-01 13:53:51'),
(38, 'avatar.png', '32916-53726-avatar.png', 8364709215, 1, 3617052498, 0, '2020-12-01 16:59:16', '2020-12-01 16:59:16'),
(39, 'avatar2.png', '82309-92058-avatar2.png', 6894327510, 1, 245917368, 0, '2020-12-01 16:59:19', '2020-12-01 16:59:19'),
(40, 'avatar3.png', '09631-avatar3.png', 7094531862, 1, 1476032985, 0, '2020-12-02 14:46:28', '2020-12-02 14:46:28'),
(41, 'avatar4.png', '48037-avatar4.png', 3570812496, 1, 9047651238, 0, '2020-12-02 14:46:30', '2020-12-02 14:46:30'),
(42, 'user1-128x128.jpg', '45718-user1-128x128.jpg', 5832619740, 1, 3217086459, 0, '2020-12-02 14:54:27', '2020-12-02 14:54:27'),
(43, 'user1-128x128.jpg', '21073-user1-128x128.jpg', 1763054298, 1, 4175903826, 0, '2020-12-02 14:55:43', '2020-12-02 14:55:43'),
(44, 'avatar.png', '12374-avatar.png', 4791258063, 1, 3729015468, 0, '2020-12-02 14:55:57', '2020-12-02 14:55:57'),
(45, 'prod-2.jpg', '97613-prod-2.jpg', 9436801725, 1, 8725934016, 0, '2020-12-02 14:56:05', '2020-12-02 14:56:05'),
(46, 'user7-128x128.jpg', '10386-user7-128x128.jpg', 8942530167, 1, 8752439601, 0, '2020-12-02 14:57:24', '2020-12-02 14:57:24'),
(47, 'user1-128x128.jpg', '05739-user1-128x128.jpg', 7041625938, 1, 1496372850, 0, '2020-12-02 14:57:29', '2020-12-02 14:57:29'),
(48, 'prod-4.jpg', '85043-prod-4.jpg', 2097185364, 1, 2713098645, 0, '2020-12-02 14:57:35', '2020-12-02 14:57:35'),
(49, 'user2-160x160.jpg', '78021-user2-160x160.jpg', 5429180376, 1, 3960257418, 70532, '2020-12-02 15:08:06', '2020-12-02 15:08:06'),
(50, 'MAPPING.docx', '72594-MAPPING.docx', 4509137682, 0, NULL, 12, '2020-12-02 15:32:29', '2020-12-02 15:32:29'),
(51, 'noc_codes.csv', '75910-noc_codes.csv', 4051876932, 0, NULL, 12, '2020-12-02 15:34:40', '2020-12-02 15:34:40'),
(52, '58187-109314.jpg', '80519-58187-109314.jpg', 1580697342, 0, NULL, 12, '2020-12-02 15:35:59', '2020-12-02 15:35:59'),
(53, 'default-150x150.png', '48649-default-150x150.png', 3114782956, 0, NULL, 0, '2020-12-05 17:16:50', '2020-12-05 17:16:50'),
(54, 'avatar3.png', '24830-avatar3.png', 1251796843, 0, NULL, 0, '2020-12-06 13:37:33', '2020-12-06 13:37:33'),
(55, 'avatar3.png', '31432-avatar3.png', 7925841163, 0, NULL, 0, '2020-12-06 13:38:13', '2020-12-06 13:38:13'),
(56, 'avatar2.png', '58916-avatar2.png', 6591784132, 0, NULL, 1, '2020-12-06 13:51:41', '2020-12-06 13:51:41'),
(57, 'avatar4.png', '4772-avatar4.png', 9871635214, 0, NULL, 0, '2020-12-06 15:44:25', '2020-12-06 15:44:25'),
(58, 'user8-128x128.jpg', '93237-user8-128x128.jpg', 9348125617, 0, NULL, 0, '2020-12-06 15:45:04', '2020-12-06 15:45:04'),
(59, 'user5-128x128.jpg', '46191-user5-128x128.jpg', 1953718246, 1, 5742160839, 70532, '2020-12-06 15:55:34', '2020-12-06 15:55:34'),
(60, 'avatar3.png', '17063-avatar3.png', 5241789361, 0, NULL, 0, '2020-12-07 04:35:50', '2020-12-07 04:35:50'),
(61, 'avatar2.png', '94629-avatar2.png', 3286719415, 0, NULL, 0, '2020-12-07 09:00:26', '2020-12-07 09:00:26'),
(62, 'avatar3.png', '31801-avatar3.png', 2196584137, 0, NULL, 0, '2020-12-07 09:01:45', '2020-12-07 09:01:45'),
(63, 'avatar3.png', '11470-avatar3.png', 2117358946, 0, NULL, 0, '2020-12-07 09:02:01', '2020-12-07 09:02:01'),
(64, 'avatar3.png', '274-avatar3.png', 4978121635, 0, NULL, 0, '2020-12-07 09:03:06', '2020-12-07 09:03:06'),
(65, 'avatar3.png', '72644-avatar3.png', 1935186274, 0, NULL, 0, '2020-12-07 09:04:42', '2020-12-07 09:04:42'),
(66, 'user7-128x128.jpg', '22485-user7-128x128.jpg', 1561238947, 0, NULL, 0, '2020-12-08 13:56:25', '2020-12-08 13:56:25'),
(67, 'user8-128x128.jpg', '91059-user8-128x128.jpg', 1257489316, 0, NULL, 0, '2020-12-08 14:00:55', '2020-12-08 14:00:55'),
(68, 'avatar2.png', '43681-avatar2.png', 5321617948, 0, NULL, 1, '2020-12-09 15:53:08', '2020-12-09 15:53:08'),
(69, 'AdminLTELogo.png', '31175-AdminLTELogo.png', 9341726581, 0, NULL, 1, '2020-12-09 15:53:09', '2020-12-09 15:53:09'),
(70, 'avatar3.png', '67214-avatar3.png', 8431159267, 0, NULL, 1, '2020-12-09 15:53:09', '2020-12-09 15:53:09'),
(71, 'boxed-bg.jpg', '35089-boxed-bg.jpg', 5481792136, 0, NULL, 0, '2020-12-28 05:20:37', '2020-12-28 05:20:37'),
(72, 'avatar2.png', '64943-avatar2.png', 3629475811, 0, NULL, 0, '2020-12-28 05:46:46', '2020-12-28 05:46:46'),
(73, 'avatar.png', '75082-avatar.png', 3718146295, 0, NULL, 0, '2020-12-28 05:57:01', '2020-12-28 05:57:01'),
(74, 'photo2.png', '84969-photo2.png', 2836719514, 0, NULL, 0, '2020-12-28 05:59:02', '2020-12-28 05:59:02'),
(75, 'photo1.png', '79509-photo1.png', 8165237941, 0, NULL, 0, '2020-12-30 16:25:20', '2020-12-30 16:25:20'),
(76, 'prod-4.jpg', '57960-prod-4.jpg', 1253769148, 0, NULL, 0, '2020-12-30 16:25:59', '2020-12-30 16:25:59'),
(77, 'user2-160x160.jpg', '71073-user2-160x160.jpg', 2157146398, 0, NULL, 0, '2020-12-30 16:37:29', '2020-12-30 16:37:29'),
(78, 'photo2.png', '19652-photo2.png', 7523411968, 0, NULL, 1, '2020-12-31 16:36:02', '2020-12-31 16:36:02'),
(79, 'photo3.jpg', '49171-photo3.jpg', 1319857462, 0, NULL, 1, '2020-12-31 16:36:03', '2020-12-31 16:36:03'),
(80, 'photo4.jpg', '58311-photo4.jpg', 1645237891, 0, NULL, 1, '2020-12-31 16:36:03', '2020-12-31 16:36:03'),
(81, 'cirrus.png', '97215-cirrus.png', 2179638541, 0, NULL, 12, '2021-01-21 14:28:10', '2021-01-21 14:28:10'),
(82, 'american-express.png', '64893-american-express.png', 4193867215, 0, NULL, 12, '2021-01-21 14:28:12', '2021-01-21 14:28:12'),
(83, 'visa.png', '12379-visa.png', 5731142986, 0, NULL, 12, '2021-01-21 14:28:38', '2021-01-21 14:28:38'),
(84, 'american-express.png', '53671-american-express.png', 3864127195, 0, NULL, 12, '2021-01-21 14:30:31', '2021-01-21 14:30:31'),
(85, 'motivational-quotes-hd-wallpapers - Copy.jpg', '61291-motivational-quotes-hd-wallpapers - Copy.jpg', 6915437812, 0, NULL, 12, '2021-01-21 14:31:10', '2021-01-21 14:31:10'),
(86, '75910-noc_codes.csv', '18417-75910-noc_codes.csv', 1726458319, 0, NULL, 12, '2021-01-21 14:56:05', '2021-01-21 14:56:05'),
(87, 'boxed-bg.jpg', '45082-boxed-bg.jpg', 1627814539, 0, NULL, 0, '2021-01-21 15:57:03', '2021-01-21 15:57:03'),
(88, 'avatar5.png', '80419-avatar5.png', 9372415618, 0, NULL, 0, '2021-01-21 15:57:10', '2021-01-21 15:57:10'),
(89, 'photo1.png', '88485-photo1.png', 3561129847, 0, NULL, 0, '2021-01-21 15:58:20', '2021-01-21 15:58:20'),
(90, 'avatar5.png', '48279-avatar5.png', 7413156928, 0, NULL, 0, '2021-01-21 16:00:33', '2021-01-21 16:00:33'),
(91, 'avatar4.png', '29935-avatar4.png', 3872196541, 0, NULL, 0, '2021-01-21 16:02:08', '2021-01-21 16:02:08'),
(92, 'avatar5.png', '83261-avatar5.png', 8762141935, 0, NULL, 0, '2021-01-21 16:03:09', '2021-01-21 16:03:09'),
(93, 'photo1.png', '55998-photo1.png', 1946358127, 0, NULL, 0, '2021-01-21 16:03:55', '2021-01-21 16:03:55'),
(94, 'photo1.png', '60829-photo1.png', 1894316275, 0, NULL, 0, '2021-01-21 16:05:18', '2021-01-21 16:05:18'),
(95, 'user8-128x128.jpg', '37359-user8-128x128.jpg', 6482591713, 0, NULL, 0, '2021-01-21 16:09:53', '2021-01-21 16:09:53'),
(96, 'testing-17-10-2020.pdf', '12600-testing-17-10-2020.pdf', 4972368511, 0, NULL, 0, '2021-01-22 16:21:23', '2021-01-22 16:21:23'),
(97, 'Android_Setup_document.pdf', '72959-Android_Setup_document.pdf', 5641391827, 0, NULL, 0, '2021-01-22 16:21:37', '2021-01-22 16:21:37'),
(98, 'user3-128x128.jpg', '1611734523-user3-128x128.jpg', 1938725461, 0, NULL, 0, '2021-01-27 16:02:04', '2021-01-27 16:02:04'),
(99, 'user4-128x128.jpg', '1611734526-user4-128x128.jpg', 6749538211, 0, NULL, 0, '2021-01-27 16:02:06', '2021-01-27 16:02:06'),
(100, 'immi.pdf', '1611734610-immi.pdf', 8137145962, 0, NULL, 0, '2021-01-27 16:03:31', '2021-01-27 16:03:31'),
(101, 'photo2.png', '1611736021-photo2.png', 5483791261, 0, NULL, 0, '2021-01-27 16:27:02', '2021-01-27 16:27:02'),
(102, 'photo3.jpg', '1611736024-photo3.jpg', 9576213184, 0, NULL, 0, '2021-01-27 16:27:04', '2021-01-27 16:27:04'),
(103, '60829-photo1.png', '1612076969-60829-photo1.png', 7619534128, 0, NULL, 0, '2021-01-31 15:09:31', '2021-01-31 15:09:31'),
(104, 'imm5257e.pdf', '1612076971-imm5257e.pdf', 9146827351, 0, NULL, 0, '2021-01-31 15:09:34', '2021-01-31 15:09:34'),
(105, '66973-93258-109314.jpg', '1612077132-66973-93258-109314.jpg', 6254391187, 0, NULL, 0, '2021-01-31 15:12:15', '2021-01-31 15:12:15'),
(106, 'IMM5257-Application for Temporary Resident Visa [IMM 5257] (PDF 0.56 MB) (Jane Doe).pdf', '1612077135-IMM5257-Application for Temporary Resident Visa [IMM 5257] (PDF 0.56 MB) (Jane Doe).pdf', 7683115924, 0, NULL, 0, '2021-01-31 15:12:18', '2021-01-31 15:12:18'),
(107, '49171-photo3.jpg', '1612077182-49171-photo3.jpg', 6135842719, 0, NULL, 0, '2021-01-31 15:13:05', '2021-01-31 15:13:05'),
(108, '2stallions-300x300.jpg', '1612081762-2stallions-300x300.jpg', 7815469132, 0, NULL, 0, '2021-01-31 16:29:24', '2021-01-31 16:29:24'),
(109, '49171-photo3.jpg', '1612081764-49171-photo3.jpg', 1847361952, 0, NULL, 0, '2021-01-31 16:29:26', '2021-01-31 16:29:26'),
(110, 'immi-30-12.pdf', '92186-immi-30-12.pdf', 7138612945, 1, 1951326784, 0, '2021-02-10 16:23:54', '2021-02-10 16:23:54'),
(111, 'immi.pdf', '61495-immi.pdf', 5391826741, 1, 6118239745, 0, '2021-02-10 16:23:55', '2021-02-10 16:23:55'),
(112, 'apple-touch-icon-72x72.png', '82963-apple-touch-icon-72x72.png', 2146159387, 1, 2963814157, 0, '2021-02-10 16:23:55', '2021-02-10 16:23:55'),
(113, 'apple-touch-icon-114x114.png', '95764-apple-touch-icon-114x114.png', 1716983254, 1, 7391241685, 0, '2021-02-10 16:23:55', '2021-02-10 16:23:55');

-- --------------------------------------------------------

--
-- Table structure for table `document_chats`
--

DROP TABLE IF EXISTS `document_chats`;
CREATE TABLE `document_chats` (
  `id` int(11) NOT NULL,
  `case_id` bigint(20) NOT NULL,
  `document_id` bigint(20) NOT NULL,
  `message` text NOT NULL,
  `file_id` bigint(20) NOT NULL DEFAULT '0',
  `send_by` varchar(100) NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `user_read` int(11) NOT NULL DEFAULT '0',
  `admin_read` int(11) NOT NULL DEFAULT '0',
  `type` varchar(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `document_chats`
--

INSERT INTO `document_chats` (`id`, `case_id`, `document_id`, `message`, `file_id`, `send_by`, `created_by`, `user_read`, `admin_read`, `type`, `created_at`, `updated_at`) VALUES
(1, 4532907168, 5469123087, 'test', 0, 'client', 70532, 0, 0, 'text', '2020-12-04 17:31:21', '2020-12-04 17:31:21'),
(2, 4532907168, 5746213809, 'test', 0, 'client', 70532, 0, 0, 'text', '2020-12-04 17:42:09', '2020-12-04 17:42:09'),
(3, 4532907168, 5746213809, 'thisismytestmessage', 0, 'client', 70532, 0, 0, 'text', '2020-12-04 17:42:39', '2020-12-04 17:42:39'),
(4, 4532907168, 5746213809, 'ffdsffsd', 0, 'client', 70532, 0, 0, 'text', '2020-12-05 14:39:17', '2020-12-05 14:39:17'),
(5, 4532907168, 5746213809, 'ccc ccc', 0, 'client', 70532, 0, 0, 'text', '2020-12-05 14:40:40', '2020-12-05 14:40:40'),
(6, 4532907168, 5746213809, 'vcvcvcc', 0, 'client', 70532, 0, 0, 'text', '2020-12-05 14:41:12', '2020-12-05 14:41:12'),
(7, 4532907168, 5746213809, 'fdsfdsfds', 0, 'client', 70532, 0, 0, 'text', '2020-12-05 14:41:17', '2020-12-05 14:41:17'),
(8, 4532907168, 5469123087, 'vbvbv gffgf', 0, 'client', 70532, 0, 0, 'text', '2020-12-05 14:43:41', '2020-12-05 14:43:41'),
(9, 4532907168, 5469123087, 'vvcvc', 0, 'client', 70532, 0, 0, 'text', '2020-12-05 14:43:52', '2020-12-05 14:43:52'),
(10, 4532907168, 5469123087, 'vcvccvc', 0, 'client', 70532, 0, 0, 'text', '2020-12-05 14:44:18', '2020-12-05 14:44:18'),
(11, 4532907168, 5469123087, 'vccvcvc', 0, 'client', 70532, 0, 0, 'text', '2020-12-05 14:44:21', '2020-12-05 14:44:21'),
(12, 4532907168, 5746213809, 'test', 0, 'admin', 8911642537, 0, 0, 'text', '2020-12-05 15:10:57', '2020-12-05 15:10:57'),
(13, 4532907168, 5469123087, 'testt', 0, 'admin', 8911642537, 0, 0, 'text', '2020-12-05 15:51:29', '2020-12-05 15:51:29'),
(14, 4532907168, 5469123087, 'tgerst', 0, 'admin', 8911642537, 0, 0, 'text', '2020-12-05 15:53:00', '2020-12-05 15:53:00'),
(15, 4532907168, 5469123087, 'dddggg', 0, 'admin', 8911642537, 0, 0, 'text', '2020-12-05 15:55:17', '2020-12-05 15:55:17'),
(16, 4532907168, 8215069743, 'cb d', 0, 'admin', 8911642537, 0, 0, 'text', '2020-12-05 15:56:14', '2020-12-05 15:56:14'),
(17, 4532907168, 1728956430, 'test', 0, 'admin', 8911642537, 0, 0, 'text', '2020-12-05 15:56:29', '2020-12-05 15:56:29'),
(18, 4532907168, 1728956430, 'vcvcvcvc', 0, 'admin', 8911642537, 0, 0, 'text', '2020-12-05 15:56:33', '2020-12-05 15:56:33'),
(19, 4532907168, 1728956430, 'bbbb', 0, 'admin', 8911642537, 0, 0, 'text', '2020-12-05 15:56:44', '2020-12-05 15:56:44'),
(20, 4532907168, 8092431657, 'ddd', 0, 'admin', 8911642537, 0, 0, 'text', '2020-12-05 15:58:56', '2020-12-05 15:58:56'),
(21, 4532907168, 8092431657, 'dd', 0, 'admin', 8911642537, 0, 0, 'text', '2020-12-05 15:59:05', '2020-12-05 15:59:05'),
(22, 4532907168, 3128716945, 'fff', 0, 'admin', 8911642537, 0, 0, 'text', '2020-12-05 16:00:37', '2020-12-05 16:00:37'),
(23, 4532907168, 5469123087, 'gg', 0, 'admin', 8911642537, 0, 0, 'text', '2020-12-05 16:01:10', '2020-12-05 16:01:10'),
(24, 4532907168, 1728956430, 'hhh', 0, 'admin', 8911642537, 0, 0, 'text', '2020-12-05 16:01:19', '2020-12-05 16:01:19'),
(25, 4532907168, 8092431657, 'jjj', 0, 'admin', 8911642537, 0, 0, 'text', '2020-12-05 16:01:39', '2020-12-05 16:01:39'),
(26, 4532907168, 8215069743, 'default-150x150.png', 3114782956, 'client', 70532, 0, 0, 'file', '2020-12-05 17:16:50', '2020-12-05 17:16:50'),
(27, 4532907168, 8092431657, 'avatar3.png', 7925841163, 'admin', 8911642537, 0, 0, 'file', '2020-12-06 13:38:13', '2020-12-06 13:38:13'),
(28, 4532907168, 5746213809, 'fdfdfd', 0, 'client', 70532, 0, 0, 'text', '2020-12-06 15:44:15', '2020-12-06 15:44:15'),
(29, 4532907168, 5746213809, 'avatar4.png', 9871635214, 'client', 70532, 0, 0, 'file', '2020-12-06 15:44:25', '2020-12-06 15:44:25'),
(30, 4532907168, 5746213809, 'user8-128x128.jpg', 9348125617, 'client', 70532, 0, 0, 'file', '2020-12-06 15:45:04', '2020-12-06 15:45:04'),
(31, 4532907168, 5746213809, 'test tst  tes tes tes test ets', 0, 'client', 70532, 0, 0, 'text', '2020-12-07 04:35:41', '2020-12-07 04:35:41'),
(32, 4532907168, 5746213809, 'avatar3.png', 5241789361, 'client', 70532, 0, 0, 'file', '2020-12-07 04:35:51', '2020-12-07 04:35:51'),
(33, 4161739825, 8692473115, 'xcxzcxz', 0, 'admin', 8911642537, 0, 0, 'text', '2020-12-23 16:16:02', '2020-12-23 16:16:02'),
(34, 4161739825, 4681753192, 'fdfdsfdsf', 0, 'client', 70532, 0, 0, 'text', '2020-12-25 15:26:22', '2020-12-25 15:26:22'),
(35, 4161739825, 4681753192, 'cvcv', 0, 'client', 70532, 0, 0, 'text', '2020-12-25 15:27:29', '2020-12-25 15:27:29'),
(36, 4161739825, 5318126749, 'fdsfsdfsd', 0, 'client', 70532, 0, 0, 'text', '2020-12-25 15:58:30', '2020-12-25 15:58:30'),
(37, 4161739825, 5318126749, 'fdsfsdfsd', 0, 'client', 70532, 0, 0, 'text', '2020-12-25 16:00:00', '2020-12-25 16:00:00'),
(38, 4161739825, 5318126749, 'xzcxzczxcc', 0, 'client', 70532, 0, 0, 'text', '2020-12-26 16:20:37', '2020-12-26 16:20:37'),
(39, 4161739825, 5318126749, 'cxcxcx', 0, 'client', 70532, 0, 0, 'text', '2020-12-26 16:20:45', '2020-12-26 16:20:45'),
(40, 4161739825, 4681753192, 'vcxvcvc cvcxvcvcvcvc', 0, 'admin', 8911642537, 0, 0, 'text', '2020-12-27 16:40:35', '2020-12-27 16:40:35'),
(41, 4161739825, 4681753192, 'fdfdfd', 0, 'admin', 8911642537, 0, 0, 'text', '2020-12-28 05:01:58', '2020-12-28 05:01:58'),
(42, 4161739825, 4681753192, 'fsdfsdfsd', 0, 'associate', 7452316819, 0, 0, 'text', '2020-12-30 15:31:19', '2020-12-30 15:31:19'),
(43, 4161739825, 4681753192, 'cvcvcvc', 0, 'admin', 8911642537, 0, 0, 'text', '2020-12-30 15:32:48', '2020-12-30 15:32:48'),
(44, 4161739825, 4681753192, 'vcvcvcxv vcxvcxvcxvvvvcvc', 0, 'associate', 7452316819, 0, 0, 'text', '2020-12-30 16:18:26', '2020-12-30 16:18:26'),
(45, 4161739825, 4681753192, 'vcvcvcxv vcxvcxvcxvvvvcvc', 0, 'associate', 7452316819, 0, 0, 'text', '2020-12-30 16:18:33', '2020-12-30 16:18:33'),
(46, 4161739825, 4681753192, 'vcvcvcxv vcxvcxvcxvvvvcvc', 0, 'associate', 7452316819, 0, 0, 'text', '2020-12-30 16:20:51', '2020-12-30 16:20:51'),
(47, 4161739825, 4681753192, 'vcvcvcxv vcxvcxvcxvvvvcvc', 0, 'associate', 7452316819, 0, 0, 'text', '2020-12-30 16:21:44', '2020-12-30 16:21:44'),
(48, 4161739825, 4681753192, 'vcvcvcxv vcxvcxvcxvvvvcvc', 0, 'associate', 7452316819, 0, 0, 'text', '2020-12-30 16:22:07', '2020-12-30 16:22:07'),
(49, 4161739825, 4681753192, 'vcvcvcxv vcxvcxvcxvvvvcvc', 0, 'associate', 7452316819, 0, 0, 'text', '2020-12-30 16:24:09', '2020-12-30 16:24:09'),
(50, 4161739825, 4681753192, 'photo1.png', 8165237941, 'associate', 7452316819, 0, 0, 'file', '2020-12-30 16:25:20', '2020-12-30 16:25:20'),
(51, 4161739825, 4681753192, 'prod-4.jpg', 1253769148, 'associate', 7452316819, 0, 0, 'file', '2020-12-30 16:25:59', '2020-12-30 16:25:59'),
(52, 4161739825, 5318126749, 'testingmessagefornotification', 0, 'admin', 8911642537, 0, 0, 'text', '2020-12-31 14:24:17', '2020-12-31 14:24:17'),
(53, 4161739825, 5318126749, 'cxcxcxcxxcxc', 0, 'admin', 8911642537, 0, 0, 'text', '2020-12-31 14:35:41', '2020-12-31 14:35:41'),
(54, 4161739825, 1536471982, 'vcvcxvcvcx', 0, 'admin', 8911642537, 0, 0, 'text', '2020-12-31 16:36:29', '2020-12-31 16:36:29'),
(55, 4161739825, 5631278149, 'test', 0, 'client', 70532, 0, 0, 'text', '2021-01-21 14:38:01', '2021-01-21 14:38:01'),
(56, 4161739825, 5631278149, 'test', 0, 'client', 70532, 0, 0, 'text', '2021-01-21 14:38:11', '2021-01-21 14:38:11'),
(57, 4161739825, 5631278149, 'test', 0, 'client', 70532, 0, 0, 'text', '2021-01-21 14:41:08', '2021-01-21 14:41:08'),
(58, 4161739825, 5631278149, 'test', 0, 'client', 70532, 0, 0, 'text', '2021-01-21 14:44:35', '2021-01-21 14:44:35'),
(59, 4161739825, 5631278149, 'cvcvcvc', 0, 'client', 70532, 0, 0, 'text', '2021-01-21 14:56:58', '2021-01-21 14:56:58'),
(60, 4161739825, 5631278149, 'bvbbvbv', 0, 'client', 70532, 0, 0, 'text', '2021-01-21 14:57:06', '2021-01-21 14:57:06'),
(61, 4161739825, 2416317958, 'test', 0, 'admin', 8911642537, 0, 0, 'text', '2021-01-21 15:55:46', '2021-01-21 15:55:46'),
(62, 4161739825, 2416317958, 'vvbb', 0, 'admin', 8911642537, 0, 0, 'text', '2021-01-21 15:55:57', '2021-01-21 15:55:57'),
(63, 4161739825, 1483561792, 'nnnmm', 0, 'admin', 8911642537, 0, 0, 'text', '2021-01-21 15:56:59', '2021-01-21 15:56:59'),
(64, 4161739825, 1483561792, 'boxed-bg.jpg', 1627814539, 'admin', 8911642537, 0, 0, 'file', '2021-01-21 15:57:04', '2021-01-21 15:57:04'),
(65, 4161739825, 1483561792, 'avatar5.png', 9372415618, 'admin', 8911642537, 0, 0, 'file', '2021-01-21 15:57:11', '2021-01-21 15:57:11'),
(66, 4161739825, 1483561792, 'photo1.png', 3561129847, 'admin', 8911642537, 0, 0, 'file', '2021-01-21 15:58:20', '2021-01-21 15:58:20'),
(67, 4161739825, 1483561792, 'avatar5.png', 7413156928, 'admin', 8911642537, 0, 0, 'file', '2021-01-21 16:00:34', '2021-01-21 16:00:34'),
(68, 4161739825, 1483561792, 'avatar4.png', 3872196541, 'admin', 8911642537, 0, 0, 'file', '2021-01-21 16:02:09', '2021-01-21 16:02:09'),
(69, 4161739825, 1483561792, 'avatar5.png', 8762141935, 'admin', 8911642537, 0, 0, 'file', '2021-01-21 16:03:09', '2021-01-21 16:03:09'),
(70, 4161739825, 1483561792, 'photo1.png', 1946358127, 'admin', 8911642537, 0, 0, 'file', '2021-01-21 16:03:56', '2021-01-21 16:03:56'),
(71, 4161739825, 1536471982, 'photo1.png', 1894316275, 'admin', 8911642537, 0, 0, 'file', '2021-01-21 16:05:19', '2021-01-21 16:05:19'),
(72, 4161739825, 5318126749, 'user8-128x128.jpg', 6482591713, 'admin', 8911642537, 0, 0, 'file', '2021-01-21 16:09:54', '2021-01-21 16:09:54'),
(73, 4161739825, 8692473115, 'cdfdfdfdf', 0, 'admin', 8911642537, 0, 0, 'text', '2021-01-21 16:10:33', '2021-01-21 16:10:33'),
(74, 4161739825, 8692473115, 'vxvcvxvcxv', 0, 'admin', 8911642537, 0, 0, 'text', '2021-01-21 16:10:59', '2021-01-21 16:10:59'),
(75, 4161739825, 9128314657, 'vvzz', 0, 'admin', 8911642537, 0, 0, 'text', '2021-01-22 16:17:04', '2021-01-22 16:17:04'),
(76, 3524968117, 4895671213, 'test tst', 0, 'client', 9218036547, 0, 0, 'text', '2021-01-27 16:52:19', '2021-01-27 16:52:19'),
(77, 3524968117, 4895671213, 'vbvb', 0, 'client', 9218036547, 0, 0, 'text', '2021-01-27 16:52:26', '2021-01-27 16:52:26'),
(78, 4161739825, 9128314657, 'cvbbb', 0, 'client', 70532, 0, 0, 'text', '2021-01-27 17:05:24', '2021-01-27 17:05:24');

-- --------------------------------------------------------

--
-- Table structure for table `domain_details`
--

DROP TABLE IF EXISTS `domain_details`;
CREATE TABLE `domain_details` (
  `id` int(11) NOT NULL,
  `subdomain` varchar(15) NOT NULL,
  `client_secret` varchar(100) NOT NULL,
  `profile_status` int(11) NOT NULL DEFAULT '0',
  `admin_notes` text,
  `notes_updated_on` varchar(100) DEFAULT NULL,
  `master_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `domain_details`
--

INSERT INTO `domain_details` (`id`, `subdomain`, `client_secret`, `profile_status`, `admin_notes`, `notes_updated_on`, `master_id`, `created_at`, `updated_at`) VALUES
(1, 'fastzone', 'TMIxaO3v7oyFZtQy1m5HKqd4oFakhe3rhOZyHg1Z3MttQangKr', 2, NULL, NULL, 1, '2020-11-03 17:25:48', '2020-11-12 15:22:46');

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
CREATE TABLE `invoices` (
  `id` int(11) NOT NULL,
  `unique_id` bigint(20) NOT NULL,
  `client_id` bigint(20) NOT NULL,
  `amount` decimal(11,2) NOT NULL,
  `payment_status` varchar(20) NOT NULL,
  `paid_date` datetime DEFAULT NULL,
  `paid_by` bigint(20) NOT NULL DEFAULT '0',
  `paid_amount` decimal(11,2) NOT NULL DEFAULT '0.00',
  `transaction_response` text,
  `payment_method` varchar(255) DEFAULT NULL,
  `link_to` varchar(100) NOT NULL,
  `link_id` bigint(20) NOT NULL,
  `bill_from` text,
  `bill_to` text,
  `invoice_date` varchar(100) DEFAULT NULL,
  `due_date` varchar(100) DEFAULT NULL,
  `created_by` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`id`, `unique_id`, `client_id`, `amount`, `payment_status`, `paid_date`, `paid_by`, `paid_amount`, `transaction_response`, `payment_method`, `link_to`, `link_id`, `bill_from`, `bill_to`, `invoice_date`, `due_date`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 8176329541, 70532, '400.00', 'paid', '2020-12-18 08:06:45', 70532, '400.00', '{\"razorpay_order_id\":\"order_GECyQI4Oge5ccz\",\"razorpay_payment_id\":\"pay_GECyR2cN1NuSGw\",\"razorpay_signature\":\"fb199df5f5a5c4875926102a6df85e071b2d5bf36b51acd644ce86148fe1491d\"}', 'wallet', 'case', 4161739825, 'Fastzone Services\r\nfdfdsafds,\r\nCalgary,Alberta,\r\nCanada', 'Cherry Pick,\r\nmmm,\r\nAdrar, Adrar,\r\nAlgeria', '15/12/2020', '31/12/2020', 8911642537, '2020-12-16 13:48:35', '2020-12-18 16:06:45'),
(2, 1836125497, 70532, '150.00', 'paid', '2020-12-19 06:38:49', 70532, '150.00', '{\"id\":\"pay_GEa0e7ey705Hno\",\"entity\":\"payment\",\"amount\":15000,\"currency\":\"INR\",\"status\":\"captured\",\"order_id\":\"order_GEa0dM7XpMDWSb\",\"invoice_id\":null,\"international\":false,\"method\":\"netbanking\",\"amount_refunded\":0,\"refund_status\":null,\"captured\":true,\"description\":null,\"card_id\":null,\"bank\":\"ALLA\",\"wallet\":null,\"vpa\":null,\"email\":\"cherry@demo.com\",\"contact\":\"147896541230\",\"notes\":[],\"fee\":354,\"tax\":54,\"error_code\":null,\"error_description\":null,\"error_source\":null,\"error_step\":null,\"error_reason\":null,\"acquirer_data\":{\"bank_transaction_id\":\"4369785\"},\"created_at\":1608311361}', 'netbanking', 'case', 4161739825, 'Fastzone Services\r\nfdfdsafds,\r\nCalgary,Alberta,\r\nCanada', 'Cherry Pick,\r\nmmm,\r\nAdrar, Adrar,\r\nAlgeria', '19/12/2020', '23/12/2020', 8911642537, '2020-12-18 16:18:03', '2020-12-19 14:38:49'),
(3, 4192731586, 70532, '400.00', 'paid', '2020-12-19 07:37:07', 70532, '400.00', '{\"id\":\"pay_GEb0EG9U5HQedH\",\"entity\":\"payment\",\"amount\":40000,\"currency\":\"INR\",\"status\":\"captured\",\"order_id\":\"order_GEb0D7VQDYs9oo\",\"invoice_id\":null,\"international\":false,\"method\":\"card\",\"amount_refunded\":0,\"refund_status\":null,\"captured\":true,\"description\":null,\"card_id\":\"card_ES9HCsm7iHCrQI\",\"card\":{\"id\":\"card_ES9HCsm7iHCrQI\",\"entity\":\"card\",\"name\":\"John Doe\",\"last4\":\"1111\",\"network\":\"Visa\",\"type\":\"debit\",\"issuer\":null,\"international\":false,\"emi\":false,\"sub_type\":\"consumer\"},\"bank\":null,\"wallet\":null,\"vpa\":null,\"email\":\"cherry@demo.com\",\"contact\":\"147896541230\",\"notes\":[],\"fee\":800,\"tax\":0,\"error_code\":null,\"error_description\":null,\"error_source\":null,\"error_step\":null,\"error_reason\":null,\"acquirer_data\":{\"auth_code\":\"710000\"},\"created_at\":1608314859}', 'card', 'case', 4161739825, 'Fastzone Services\r\nfdfdsafds,\r\nCalgary,Alberta,\r\nCanada', 'Cherry Pick,\r\nmmm,\r\nAdrar, Adrar,\r\nAlgeria', '19/12/2020', '30/12/2020', 8911642537, '2020-12-19 15:35:32', '2020-12-19 15:37:07'),
(4, 2195431786, 70532, '610.00', 'pending', NULL, 0, '0.00', NULL, NULL, 'case', 4161739825, 'Fastzone Services\r\nfdfdsafds,\r\nCalgary,Alberta,\r\nCanada', 'Cherry Pick,\r\nmmm,\r\nAdrar, Adrar,\r\nAlgeria', '25/12/2020', '31/12/2020', 8911642537, '2020-12-25 16:30:19', '2020-12-25 16:30:19'),
(5, 7329518146, 70532, '44.00', 'pending', NULL, 0, '0.00', NULL, NULL, 'case', 4161739825, 'Fastzone Services\r\nfdfdsafds,\r\nCalgary,Alberta,\r\nCanada', 'Cherry Pick,\r\nmmm,\r\nAdrar, Adrar,\r\nAlgeria', '26/12/2020', '30/12/2020', 8911642537, '2020-12-25 16:57:24', '2020-12-25 16:57:24'),
(6, 3162859417, 70532, '44.00', 'pending', NULL, 0, '0.00', NULL, NULL, 'case', 4161739825, 'Fastzone Services\r\nfdfdsafds,\r\nCalgary,Alberta,\r\nCanada', 'Cherry Pick,\r\nmmm,\r\nAdrar, Adrar,\r\nAlgeria', '26/12/2020', '30/12/2020', 8911642537, '2020-12-25 16:57:33', '2020-12-25 16:57:33'),
(7, 9136574821, 70532, '44.00', 'pending', NULL, 0, '0.00', NULL, NULL, 'case', 4161739825, 'Fastzone Services\r\nfdfdsafds,\r\nCalgary,Alberta,\r\nCanada', 'Cherry Pick,\r\nmmm,\r\nAdrar, Adrar,\r\nAlgeria', '26/12/2020', '30/12/2020', 8911642537, '2020-12-25 17:00:26', '2020-12-25 17:00:26'),
(8, 4219316857, 9218036547, '350.00', 'pending', NULL, 0, '0.00', NULL, NULL, 'case', 3524968117, 'Fastzone Services\r\nfdfdsafds,\r\nCalgary,Alberta,\r\nCanada', 'DK Dev,\r\nmmm,\r\nAdrar, Adrar,\r\nAlgeria', '22/01/2021', '30/01/2021', 8911642537, '2021-01-22 16:12:43', '2021-01-22 16:13:36'),
(9, 8392751641, 9218036547, '500.00', 'pending', NULL, 0, '0.00', NULL, NULL, 'case', 1961485732, 'Fastzone Services\r\nfdfdsafds,\r\nCalgary,Alberta,\r\nCanada', 'DK Dev,\r\nmmm,\r\nAdrar, Adrar,\r\nAlgeria', '22/01/2021', '04/02/2021', 8911642537, '2021-01-22 16:50:41', '2021-01-22 16:50:41');

-- --------------------------------------------------------

--
-- Table structure for table `leads`
--

DROP TABLE IF EXISTS `leads`;
CREATE TABLE `leads` (
  `id` int(11) NOT NULL,
  `unique_id` bigint(20) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `country_code` varchar(10) DEFAULT NULL,
  `phone_no` varchar(200) DEFAULT NULL,
  `date_of_birth` varchar(20) DEFAULT NULL,
  `gender` varchar(100) DEFAULT NULL,
  `visa_service_id` bigint(20) NOT NULL DEFAULT '0',
  `country_id` int(11) NOT NULL DEFAULT '0',
  `state_id` int(11) NOT NULL DEFAULT '0',
  `city_id` int(11) NOT NULL DEFAULT '0',
  `address` text,
  `zip_code` varchar(15) DEFAULT NULL,
  `mark_as_client` int(11) DEFAULT '0',
  `master_id` bigint(20) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `leads`
--

INSERT INTO `leads` (`id`, `unique_id`, `first_name`, `last_name`, `email`, `country_code`, `phone_no`, `date_of_birth`, `gender`, `visa_service_id`, `country_id`, `state_id`, `city_id`, `address`, `zip_code`, `mark_as_client`, `master_id`, `created_by`, `created_at`, `updated_at`) VALUES
(3, 5263187409, 'Mark', 'Doe', 'mark@demo.com', '+91', '7894561230', '01/02/2000', NULL, 1207953846, 0, 0, 0, NULL, NULL, 0, 0, 0, '2020-11-10 17:32:19', '2021-01-21 16:51:47'),
(4, 6975321480, 'John', 'Doe', 'john@demo.com', '+91', '1234567890', '13/07/2005', NULL, 1207953846, 0, 0, 0, NULL, NULL, 2, 0, 0, '2020-11-11 13:33:34', '2021-01-22 14:54:21'),
(5, 4820369175, 'Ashit', 'Charlie', 'ashit@demo.com', '+91', '745632104', '22/06/1994', NULL, 2940376815, 0, 0, 0, NULL, NULL, 1, 7829, 0, '2020-11-11 13:35:53', '2020-11-14 14:59:05'),
(6, 7053482169, 'Cherry', 'Pick', 'cherry@demo.com', '+91', '147896541230', '02/12/1999', NULL, 1207953846, 0, 0, 0, NULL, NULL, 1, 70532, 0, '2020-11-11 15:25:18', '2020-11-14 14:55:22'),
(7, 2311458769, 'DK', 'Dev', 'dkdev215@ggmail.com', '+93', '98745632110', '12/06/2007', NULL, 6510423798, 0, 0, 0, NULL, NULL, 1, 5641718923, 0, '2021-01-21 16:34:49', '2021-01-21 16:38:16'),
(8, 3182546791, 'Lead', 'DK', 'dkdev2415@gmail.com', '+91', '78945612307', '09/06/1999', NULL, 6518273409, 0, 0, 0, NULL, NULL, 1, 9218036547, 0, '2021-01-21 16:53:14', '2021-01-21 17:11:50');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(11) NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `notification_type` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `send_by` varchar(100) NOT NULL,
  `added_by` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `type`, `notification_type`, `title`, `comment`, `url`, `send_by`, `added_by`, `created_at`, `updated_at`) VALUES
(1, 'chat', 'case_chat', 'Message by Client Cherry Pick', 'vcvcxcvcxv', 'cases/chats/4161739825?chat_type=case_chat', 'client', 70532, '2020-12-24 16:17:36', '2020-12-24 16:17:36'),
(2, 'chat', 'document_chat', 'Message on document by Client Cherry Pick', 'fdsfsdfsd', 'cases/case-documents/extra/4161739825/5318126749', 'client', 70532, '2020-12-25 15:58:30', '2020-12-25 15:58:30'),
(3, 'chat', 'document_chat', 'Message on document by Client Cherry Pick', 'fdsfsdfsd', 'cases/case-documents/extra/4161739825/5318126749', 'client', 70532, '2020-12-25 16:00:00', '2020-12-25 16:00:00'),
(4, 'chat', 'document_chat', 'Message on document by Client Cherry Pick', 'xzcxzczxcc', 'cases/case-documents/extra/4161739825/2351918746', 'client', 70532, '2020-12-26 16:20:38', '2020-12-26 16:20:38'),
(5, 'chat', 'document_chat', 'Message on document by Client Cherry Pick', 'cxcxcx', 'cases/case-documents/extra/4161739825/2351918746', 'client', 70532, '2020-12-26 16:20:45', '2020-12-26 16:20:45'),
(6, 'chat', 'document_chat', 'Message on document by Client Daniel Doe', 'vcvcvcxv vcxvcxvcxvvvvcvc', NULL, 'associate', 7452316819, '2020-12-30 16:24:10', '2020-12-30 16:24:10'),
(7, 'chat', 'document_chat', 'Message on document by Client Daniel Doe', 'Document send in chat', NULL, 'associate', 7452316819, '2020-12-30 16:25:59', '2020-12-30 16:25:59'),
(8, 'chat', 'general', 'Fastzone Services send message on document', 'cvcxvcv', 'cases/chats/4161739825', 'associate', 7452316819, '2020-12-30 16:37:22', '2020-12-30 16:37:22'),
(9, 'chat', 'general', 'Fastzone Services send message on document', 'Document send in chat', 'cases/chats/4161739825', 'associate', 7452316819, '2020-12-30 16:37:30', '2020-12-30 16:37:30'),
(10, 'chat', 'document_chat', 'Message on document by Fastzone Services', 'testingmessagefornotification', NULL, 'admin', 8911642537, '2020-12-31 14:24:17', '2020-12-31 14:24:17'),
(11, 'chat', 'document_chat', 'Message on document by Fastzone Services', 'cxcxcxcxxcxc', 'cases/case-documents/extra/4161739825/2351918746', 'admin', 8911642537, '2020-12-31 14:35:41', '2020-12-31 14:35:41'),
(12, 'chat', 'document_chat', 'Message on document by Fastzone Services', 'vcvcxvcvcx', 'cases/case-documents/default/4161739825/63724', 'admin', 8911642537, '2020-12-31 16:36:29', '2020-12-31 16:36:29'),
(13, 'chat', 'document_chat', 'Message on document by Client Cherry Pick', 'test', NULL, 'client', 70532, '2021-01-21 14:38:01', '2021-01-21 14:38:01'),
(14, 'chat', 'document_chat', 'Message on document by Client Cherry Pick', 'test', NULL, 'client', 70532, '2021-01-21 14:38:11', '2021-01-21 14:38:11'),
(15, 'chat', 'document_chat', 'Message on document by Client Cherry Pick', 'test', NULL, 'client', 70532, '2021-01-21 14:41:08', '2021-01-21 14:41:08'),
(16, 'chat', 'document_chat', 'Message on document by Client Cherry Pick', 'test', NULL, 'client', 70532, '2021-01-21 14:44:35', '2021-01-21 14:44:35'),
(17, 'chat', 'document_chat', 'Message on document by Client Cherry Pick', 'cvcvcvc', 'cases/case-documents/extra/4161739825/2351918746', 'client', 70532, '2021-01-21 14:56:58', '2021-01-21 14:56:58'),
(18, 'chat', 'document_chat', 'Message on document by Client Cherry Pick', 'bvbbvbv', 'cases/case-documents/extra/4161739825/2351918746', 'client', 70532, '2021-01-21 14:57:06', '2021-01-21 14:57:06'),
(19, 'chat', 'document_chat', 'Message on document by Fastzone Services', 'test', 'cases/case-documents/default/4161739825/63724', 'admin', 8911642537, '2021-01-21 15:55:46', '2021-01-21 15:55:46'),
(20, 'chat', 'document_chat', 'Message on document by Fastzone Services', 'vvbb', 'cases/case-documents/default/4161739825/63724', 'admin', 8911642537, '2021-01-21 15:55:57', '2021-01-21 15:55:57'),
(21, 'chat', 'document_chat', 'Message on document by Fastzone Services', 'nnnmm', 'cases/case-documents/default/4161739825/63724', 'admin', 8911642537, '2021-01-21 15:56:59', '2021-01-21 15:56:59'),
(22, 'chat', 'document_chat', 'Message on document by Fastzone Services', 'Document send in chat', 'cases/case-documents/default/4161739825/63724', 'admin', 8911642537, '2021-01-21 16:03:10', '2021-01-21 16:03:10'),
(23, 'chat', 'document_chat', 'Message on document by Fastzone Services', 'Document send in chat', 'cases/case-documents/default/4161739825/63724', 'admin', 8911642537, '2021-01-21 16:03:56', '2021-01-21 16:03:56'),
(24, 'chat', 'document_chat', 'Message on document by Fastzone Services', 'Document send in chat', 'cases/case-documents/default/4161739825/63724', 'admin', 8911642537, '2021-01-21 16:05:19', '2021-01-21 16:05:19'),
(25, 'chat', 'document_chat', 'Message on document by Fastzone Services', 'Document send in chat', 'cases/case-documents/extra/4161739825/2351918746', 'admin', 8911642537, '2021-01-21 16:09:54', '2021-01-21 16:09:54'),
(26, 'chat', 'document_chat', 'Message on document by Fastzone Services', 'cdfdfdfdf', 'cases/case-documents/extra/4161739825/2351918746', 'admin', 8911642537, '2021-01-21 16:10:33', '2021-01-21 16:10:33'),
(27, 'chat', 'document_chat', 'Message on document by Fastzone Services', 'vxvcvxvcxv', 'cases/case-documents/extra/4161739825/2351918746', 'admin', 8911642537, '2021-01-21 16:10:59', '2021-01-21 16:10:59'),
(28, 'chat', 'document_chat', 'Message on document by Fastzone Services', 'vvzz', 'cases/case-documents/default/4161739825/63724', 'admin', 8911642537, '2021-01-22 16:17:04', '2021-01-22 16:17:04'),
(29, 'chat', 'general', 'Fastzone Services send message on document', 'fdfdfd', 'cases/chats/1961485732', 'admin', 8911642537, '2021-01-22 16:21:00', '2021-01-22 16:21:00'),
(30, 'chat', 'general', 'Fastzone Services send message on document', 'Document send in chat', 'cases/chats/1961485732', 'admin', 8911642537, '2021-01-22 16:21:23', '2021-01-22 16:21:23'),
(31, 'chat', 'case_chat', 'Fastzone Services send message on document', 'Document send in chat', 'cases/chats/1961485732?chat_type=case_chat', 'admin', 8911642537, '2021-01-22 16:21:38', '2021-01-22 16:21:38'),
(32, 'chat', 'document_chat', 'Message on document by Client DK Dev', 'test tst', 'cases/case-documents/default/3524968117/95324', 'client', 9218036547, '2021-01-27 16:52:19', '2021-01-27 16:52:19'),
(33, 'chat', 'document_chat', 'Message on document by Client DK Dev', 'vbvb', 'cases/case-documents/default/3524968117/95324', 'client', 9218036547, '2021-01-27 16:52:26', '2021-01-27 16:52:26'),
(34, 'chat', 'document_chat', 'Message on document by Client Cherry Pick', 'cvbbb', 'cases/case-documents/default/4161739825/63724', 'client', 70532, '2021-01-27 17:05:24', '2021-01-27 17:05:24');

-- --------------------------------------------------------

--
-- Table structure for table `notification_data`
--

DROP TABLE IF EXISTS `notification_data`;
CREATE TABLE `notification_data` (
  `id` int(11) NOT NULL,
  `notification_id` int(11) NOT NULL,
  `meta_key` varchar(255) NOT NULL,
  `meta_value` text NOT NULL,
  `send_by` varchar(100) NOT NULL,
  `added_by` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notification_data`
--

INSERT INTO `notification_data` (`id`, `notification_id`, `meta_key`, `meta_value`, `send_by`, `added_by`, `created_at`, `updated_at`) VALUES
(1, 1, 'chat_type', 'case_chat', 'client', 70532, '2020-12-24 16:17:36', '2020-12-24 16:17:36'),
(2, 1, 'case_id', '4161739825', 'client', 70532, '2020-12-24 16:17:36', '2020-12-24 16:17:36'),
(3, 2, 'case_id', '4161739825', 'client', 70532, '2020-12-25 15:58:30', '2020-12-25 15:58:30'),
(4, 2, 'doc_type', 'extra', 'client', 70532, '2020-12-25 15:58:30', '2020-12-25 15:58:30'),
(5, 2, 'document_id', '5318126749', 'client', 70532, '2020-12-25 15:58:30', '2020-12-25 15:58:30'),
(6, 3, 'case_id', '4161739825', 'client', 70532, '2020-12-25 16:00:00', '2020-12-25 16:00:00'),
(7, 3, 'doc_type', 'extra', 'client', 70532, '2020-12-25 16:00:00', '2020-12-25 16:00:00'),
(8, 3, 'document_id', '5318126749', 'client', 70532, '2020-12-25 16:00:00', '2020-12-25 16:00:00'),
(9, 4, 'case_id', '4161739825', 'client', 70532, '2020-12-26 16:20:38', '2020-12-26 16:20:38'),
(10, 4, 'doc_type', 'extra', 'client', 70532, '2020-12-26 16:20:38', '2020-12-26 16:20:38'),
(11, 4, 'document_id', '5318126749', 'client', 70532, '2020-12-26 16:20:38', '2020-12-26 16:20:38'),
(12, 5, 'case_id', '4161739825', 'client', 70532, '2020-12-26 16:20:45', '2020-12-26 16:20:45'),
(13, 5, 'doc_type', 'extra', 'client', 70532, '2020-12-26 16:20:45', '2020-12-26 16:20:45'),
(14, 5, 'document_id', '5318126749', 'client', 70532, '2020-12-26 16:20:46', '2020-12-26 16:20:46'),
(15, 6, 'case_id', '4161739825', 'associate', 7452316819, '2020-12-30 16:24:10', '2020-12-30 16:24:10'),
(16, 6, 'document_id', '4681753192', 'associate', 7452316819, '2020-12-30 16:24:10', '2020-12-30 16:24:10'),
(17, 7, 'case_id', '4161739825', 'associate', 7452316819, '2020-12-30 16:25:59', '2020-12-30 16:25:59'),
(18, 7, 'document_id', '4681753192', 'associate', 7452316819, '2020-12-30 16:25:59', '2020-12-30 16:25:59'),
(19, 8, 'chat_type', 'general', 'associate', 7452316819, '2020-12-30 16:37:22', '2020-12-30 16:37:22'),
(20, 9, 'chat_type', 'general', 'associate', 7452316819, '2020-12-30 16:37:30', '2020-12-30 16:37:30'),
(21, 10, 'case_id', '4161739825', 'admin', 8911642537, '2020-12-31 14:24:17', '2020-12-31 14:24:17'),
(22, 10, 'document_id', '5318126749', 'admin', 8911642537, '2020-12-31 14:24:17', '2020-12-31 14:24:17'),
(23, 11, 'case_id', '4161739825', 'admin', 8911642537, '2020-12-31 14:35:41', '2020-12-31 14:35:41'),
(24, 11, 'document_id', '5318126749', 'admin', 8911642537, '2020-12-31 14:35:41', '2020-12-31 14:35:41'),
(25, 12, 'case_id', '4161739825', 'admin', 8911642537, '2020-12-31 16:36:29', '2020-12-31 16:36:29'),
(26, 12, 'document_id', '1536471982', 'admin', 8911642537, '2020-12-31 16:36:30', '2020-12-31 16:36:30'),
(27, 13, 'case_id', '4161739825', 'client', 70532, '2021-01-21 14:38:02', '2021-01-21 14:38:02'),
(28, 14, 'case_id', '4161739825', 'client', 70532, '2021-01-21 14:38:11', '2021-01-21 14:38:11'),
(29, 15, 'case_id', '4161739825', 'client', 70532, '2021-01-21 14:41:08', '2021-01-21 14:41:08'),
(30, 16, 'case_id', '4161739825', 'client', 70532, '2021-01-21 14:44:35', '2021-01-21 14:44:35'),
(31, 16, 'document_id', '5631278149', 'client', 70532, '2021-01-21 14:44:36', '2021-01-21 14:44:36'),
(32, 17, 'case_id', '4161739825', 'client', 70532, '2021-01-21 14:56:58', '2021-01-21 14:56:58'),
(33, 17, 'document_id', '5631278149', 'client', 70532, '2021-01-21 14:56:58', '2021-01-21 14:56:58'),
(34, 18, 'case_id', '4161739825', 'client', 70532, '2021-01-21 14:57:06', '2021-01-21 14:57:06'),
(35, 18, 'document_id', '5631278149', 'client', 70532, '2021-01-21 14:57:06', '2021-01-21 14:57:06'),
(36, 19, 'case_id', '4161739825', 'admin', 8911642537, '2021-01-21 15:55:47', '2021-01-21 15:55:47'),
(37, 19, 'document_id', '2416317958', 'admin', 8911642537, '2021-01-21 15:55:48', '2021-01-21 15:55:48'),
(38, 20, 'case_id', '4161739825', 'admin', 8911642537, '2021-01-21 15:55:57', '2021-01-21 15:55:57'),
(39, 20, 'document_id', '2416317958', 'admin', 8911642537, '2021-01-21 15:55:57', '2021-01-21 15:55:57'),
(40, 21, 'case_id', '4161739825', 'admin', 8911642537, '2021-01-21 15:56:59', '2021-01-21 15:56:59'),
(41, 21, 'document_id', '1483561792', 'admin', 8911642537, '2021-01-21 15:56:59', '2021-01-21 15:56:59'),
(42, 22, 'case_id', '4161739825', 'admin', 8911642537, '2021-01-21 16:03:10', '2021-01-21 16:03:10'),
(43, 22, 'document_id', '1483561792', 'admin', 8911642537, '2021-01-21 16:03:10', '2021-01-21 16:03:10'),
(44, 23, 'case_id', '4161739825', 'admin', 8911642537, '2021-01-21 16:03:56', '2021-01-21 16:03:56'),
(45, 23, 'document_id', '1483561792', 'admin', 8911642537, '2021-01-21 16:03:56', '2021-01-21 16:03:56'),
(46, 24, 'case_id', '4161739825', 'admin', 8911642537, '2021-01-21 16:05:20', '2021-01-21 16:05:20'),
(47, 24, 'document_id', '1536471982', 'admin', 8911642537, '2021-01-21 16:05:20', '2021-01-21 16:05:20'),
(48, 25, 'case_id', '4161739825', 'admin', 8911642537, '2021-01-21 16:09:54', '2021-01-21 16:09:54'),
(49, 25, 'document_id', '5318126749', 'admin', 8911642537, '2021-01-21 16:09:54', '2021-01-21 16:09:54'),
(50, 26, 'case_id', '4161739825', 'admin', 8911642537, '2021-01-21 16:10:34', '2021-01-21 16:10:34'),
(51, 26, 'document_id', '8692473115', 'admin', 8911642537, '2021-01-21 16:10:34', '2021-01-21 16:10:34'),
(52, 27, 'case_id', '4161739825', 'admin', 8911642537, '2021-01-21 16:10:59', '2021-01-21 16:10:59'),
(53, 27, 'document_id', '8692473115', 'admin', 8911642537, '2021-01-21 16:10:59', '2021-01-21 16:10:59'),
(54, 28, 'case_id', '4161739825', 'admin', 8911642537, '2021-01-22 16:17:04', '2021-01-22 16:17:04'),
(55, 28, 'document_id', '9128314657', 'admin', 8911642537, '2021-01-22 16:17:04', '2021-01-22 16:17:04'),
(56, 29, 'chat_type', 'general', 'admin', 8911642537, '2021-01-22 16:21:00', '2021-01-22 16:21:00'),
(57, 30, 'chat_type', 'general', 'admin', 8911642537, '2021-01-22 16:21:23', '2021-01-22 16:21:23'),
(58, 31, 'chat_type', 'case_chat', 'admin', 8911642537, '2021-01-22 16:21:38', '2021-01-22 16:21:38'),
(59, 31, 'case_id', '1961485732', 'admin', 8911642537, '2021-01-22 16:21:38', '2021-01-22 16:21:38'),
(60, 32, 'case_id', '3524968117', 'client', 9218036547, '2021-01-27 16:52:19', '2021-01-27 16:52:19'),
(61, 32, 'document_id', '4895671213', 'client', 9218036547, '2021-01-27 16:52:19', '2021-01-27 16:52:19'),
(62, 33, 'case_id', '3524968117', 'client', 9218036547, '2021-01-27 16:52:26', '2021-01-27 16:52:26'),
(63, 33, 'document_id', '4895671213', 'client', 9218036547, '2021-01-27 16:52:26', '2021-01-27 16:52:26'),
(64, 34, 'case_id', '4161739825', 'client', 70532, '2021-01-27 17:05:24', '2021-01-27 17:05:24'),
(65, 34, 'document_id', '9128314657', 'client', 70532, '2021-01-27 17:05:25', '2021-01-27 17:05:25');

-- --------------------------------------------------------

--
-- Table structure for table `notification_read`
--

DROP TABLE IF EXISTS `notification_read`;
CREATE TABLE `notification_read` (
  `id` int(11) NOT NULL,
  `notification_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `user_role` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notification_read`
--

INSERT INTO `notification_read` (`id`, `notification_id`, `user_id`, `user_role`, `created_at`, `updated_at`) VALUES
(1, 1, 8911642537, 'admin', '2020-12-26 15:23:31', '2020-12-26 15:23:31'),
(2, 3, 8911642537, 'admin', '2020-12-26 15:36:02', '2020-12-26 15:36:02'),
(3, 2, 8911642537, 'admin', '2020-12-26 15:37:08', '2020-12-26 15:37:08'),
(4, 5, 8911642537, 'admin', '2020-12-26 16:21:24', '2020-12-26 16:21:24'),
(5, 4, 8911642537, 'admin', '2020-12-29 15:26:51', '2020-12-29 15:26:51'),
(6, 5, 7452316819, 'associate', '2020-12-30 15:37:57', '2020-12-30 15:37:57'),
(7, 3, 7452316819, 'associate', '2020-12-30 15:38:56', '2020-12-30 15:38:56'),
(8, 2, 7452316819, 'associate', '2020-12-30 15:39:27', '2020-12-30 15:39:27'),
(9, 1, 7452316819, 'associate', '2020-12-30 15:47:07', '2020-12-30 15:47:07'),
(10, 4, 7452316819, 'associate', '2020-12-30 15:47:10', '2020-12-30 15:47:10'),
(11, 9, 7659124831, 'manager', '2020-12-31 13:54:54', '2020-12-31 13:54:54'),
(12, 5, 7659124831, 'manager', '2020-12-31 13:55:05', '2020-12-31 13:55:05'),
(13, 2, 7659124831, 'manager', '2020-12-31 13:55:12', '2020-12-31 13:55:12'),
(14, 11, 7659124831, 'manager', '2020-12-31 14:35:55', '2020-12-31 14:35:55'),
(15, 3, 7659124831, 'manager', '2020-12-31 14:57:25', '2020-12-31 14:57:25'),
(16, 8, 7659124831, 'manager', '2020-12-31 14:58:05', '2020-12-31 14:58:05'),
(17, 12, 7659124831, 'manager', '2020-12-31 16:36:39', '2020-12-31 16:36:39');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL,
  `email` varchar(500) NOT NULL,
  `token` varchar(500) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`id`, `email`, `token`, `created_at`, `updated_at`) VALUES
(23, 'dkdev2415@gmail.com', '$2y$10$CQXXIQq3Lra5VpKV6dVhoOf4RK1qHS8SnaFHdG.WH4VDRE5Iyv3em', '2020-11-13 11:32:28', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `professional_details`
--

DROP TABLE IF EXISTS `professional_details`;
CREATE TABLE `professional_details` (
  `id` int(11) NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `website_url` varchar(500) DEFAULT NULL,
  `phone_no` varchar(255) DEFAULT NULL,
  `address` text,
  `country_code` varchar(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `state_id` int(11) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `zip_code` varchar(100) DEFAULT NULL,
  `owner_id_proof` varchar(255) DEFAULT NULL,
  `company_address_proof` varchar(255) DEFAULT NULL,
  `date_of_register` varchar(15) DEFAULT NULL,
  `license_body` text,
  `member_of_good_standing` text,
  `licence_number` varchar(25) DEFAULT NULL,
  `licence_certificate` varchar(100) DEFAULT NULL,
  `years_of_expirences` varchar(100) DEFAULT NULL,
  `member_of_other_designated_body` varchar(500) DEFAULT NULL,
  `company_logo` varchar(255) DEFAULT NULL,
  `company_banner` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `professional_details`
--

INSERT INTO `professional_details` (`id`, `company_name`, `email`, `website_url`, `phone_no`, `address`, `country_code`, `country_id`, `state_id`, `city_id`, `zip_code`, `owner_id_proof`, `company_address_proof`, `date_of_register`, `license_body`, `member_of_good_standing`, `licence_number`, `licence_certificate`, `years_of_expirences`, `member_of_other_designated_body`, `company_logo`, `company_banner`, `created_at`, `updated_at`) VALUES
(1, 'Fastzone Services', 'test@test.com', 'test.com', '124321321', 'fdfdsafds', '+91', 38, 663, 10107, '12312321', '69622-photo3.jpg', '87451-prod-4.jpg', '06/06/2018', '[\"1\",\"2\"]', 'yes', '131231232', '50357-AdminLTELogo.png', '2 to 5 years', 'test test terst', '60407-AdminLTELogo.png', NULL, '2020-11-03 17:25:48', '2021-01-22 17:08:04');

-- --------------------------------------------------------

--
-- Table structure for table `professional_services`
--

DROP TABLE IF EXISTS `professional_services`;
CREATE TABLE `professional_services` (
  `id` int(11) NOT NULL,
  `unique_id` bigint(20) NOT NULL,
  `service_id` bigint(20) NOT NULL,
  `description` text,
  `fixed_price` int(11) NOT NULL DEFAULT '0',
  `price` int(11) NOT NULL DEFAULT '0',
  `max_price` decimal(11,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `professional_services`
--

INSERT INTO `professional_services` (`id`, `unique_id`, `service_id`, `description`, `fixed_price`, `price`, `max_price`, `created_at`, `updated_at`) VALUES
(5, 7890465132, 7392460158, NULL, 0, 0, '0.00', '2020-11-09 14:56:42', '2020-11-09 14:56:42'),
(7, 1207953846, 1657239480, NULL, 0, 0, '0.00', '2020-11-10 13:54:25', '2020-11-10 13:54:25'),
(11, 2940376815, 1657239480, NULL, 0, 0, '0.00', '2020-11-10 13:54:26', '2020-11-10 13:54:26'),
(12, 7031982654, 8435910276, 'fdsdafsfdfdsf', 0, 1, '0.00', '2020-11-10 15:39:38', '2020-11-11 13:45:30'),
(13, 3251864709, 6384590271, NULL, 0, 0, '0.00', '2020-11-30 07:23:18', '2020-11-30 07:23:18'),
(14, 2643918075, 2407156398, NULL, 0, 0, '0.00', '2020-11-30 07:23:19', '2020-11-30 07:23:19'),
(15, 675312984, 6095278314, NULL, 0, 0, '0.00', '2020-11-30 07:23:20', '2020-11-30 07:23:20'),
(16, 6510423798, 8732156904, NULL, 0, 0, '0.00', '2020-11-30 07:23:21', '2020-11-30 07:23:21'),
(17, 6518273409, 1654372098, NULL, 0, 0, '0.00', '2020-11-30 07:23:21', '2020-11-30 07:23:21');

-- --------------------------------------------------------

--
-- Table structure for table `professional_settings`
--

DROP TABLE IF EXISTS `professional_settings`;
CREATE TABLE `professional_settings` (
  `id` int(11) NOT NULL,
  `meta_key` varchar(255) NOT NULL,
  `meta_value` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `reminder_notes`
--

DROP TABLE IF EXISTS `reminder_notes`;
CREATE TABLE `reminder_notes` (
  `id` int(11) NOT NULL,
  `unique_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `reminder_date` date NOT NULL,
  `notes` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reminder_notes`
--

INSERT INTO `reminder_notes` (`id`, `unique_id`, `user_id`, `reminder_date`, `notes`, `created_at`, `updated_at`) VALUES
(1, 4197261583, 8911642537, '2020-12-21', 'Testing notesfsdfdsfsdfsdfdsfdfdsf', '2020-12-22 16:09:53', '2020-12-23 15:44:04'),
(2, 4711529863, 8911642537, '2020-12-25', 'Going to add new leads', '2020-12-22 16:12:25', '2020-12-22 16:12:25');

-- --------------------------------------------------------

--
-- Table structure for table `role_privileges`
--

DROP TABLE IF EXISTS `role_privileges`;
CREATE TABLE `role_privileges` (
  `id` int(11) NOT NULL,
  `role` varchar(100) NOT NULL,
  `module` varchar(100) NOT NULL,
  `action` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role_privileges`
--

INSERT INTO `role_privileges` (`id`, `role`, `module`, `action`, `created_at`, `updated_at`) VALUES
(1, 'manager', 'cases', 'edit-case', '2020-12-30 15:53:38', '2020-12-30 15:53:38'),
(2, 'manager', 'cases', 'delete-case', '2020-12-30 15:53:38', '2020-12-30 15:53:38'),
(3, 'manager', 'cases', 'case-documents', '2020-12-30 15:53:38', '2020-12-30 15:53:38'),
(4, 'manager', 'cases', 'documents-exchanger', '2020-12-30 15:53:38', '2020-12-30 15:53:38'),
(5, 'manager', 'cases', 'add-folder', '2020-12-30 15:53:38', '2020-12-30 15:53:38'),
(6, 'manager', 'cases', 'upload-files', '2020-12-30 15:53:38', '2020-12-30 15:53:38'),
(7, 'manager', 'cases', 'delete-file', '2020-12-30 15:53:38', '2020-12-30 15:53:38'),
(8, 'manager', 'cases', 'move-to', '2020-12-30 15:53:38', '2020-12-30 15:53:38'),
(9, 'manager', 'cases', 'add-to-starred', '2020-12-30 15:53:38', '2020-12-30 15:53:38'),
(10, 'manager', 'cases', 'view-documents', '2020-12-30 15:53:38', '2020-12-30 15:53:38'),
(11, 'manager', 'cases', 'download-file', '2020-12-30 15:53:38', '2020-12-30 15:53:38'),
(12, 'manager', 'cases', 'view-file', '2020-12-30 15:53:38', '2020-12-30 15:53:38'),
(13, 'manager', 'cases', 'chat-on-document', '2020-12-30 15:53:39', '2020-12-30 15:53:39'),
(14, 'manager', 'cases', 'case-chat', '2020-12-30 15:53:39', '2020-12-30 15:53:39'),
(15, 'manager', 'cases', 'general-chat', '2020-12-30 15:53:39', '2020-12-30 15:53:39'),
(16, 'manager', 'cases', 'view-cases', '2020-12-30 15:53:39', '2020-12-30 15:53:39'),
(17, 'manager', 'cases', 'create-client', '2020-12-30 15:53:39', '2020-12-30 15:53:39'),
(18, 'manager', 'leads', 'edit-lead', '2020-12-30 15:53:39', '2020-12-30 15:53:39'),
(19, 'manager', 'leads', 'delete-lead', '2020-12-30 15:53:39', '2020-12-30 15:53:39'),
(20, 'manager', 'leads', 'mark-as-client', '2020-12-30 15:53:39', '2020-12-30 15:53:39'),
(21, 'manager', 'leads', 'view-leads', '2020-12-30 15:53:39', '2020-12-30 15:53:39'),
(22, 'manager', 'leads', 'quick-lead', '2020-12-30 15:53:39', '2020-12-30 15:53:39'),
(23, 'manager', 'leads', 'recommend-as-client', '2020-12-30 15:53:39', '2020-12-30 15:53:39'),
(24, 'manager', 'global-module', 'top-notifications', '2020-12-30 15:53:39', '2020-12-30 15:53:39'),
(25, 'associate', 'cases', 'edit-case', '2020-12-30 15:53:39', '2020-12-30 15:53:39'),
(26, 'associate', 'cases', 'case-documents', '2020-12-30 15:53:39', '2020-12-30 15:53:39'),
(27, 'associate', 'cases', 'documents-exchanger', '2020-12-30 15:53:39', '2020-12-30 15:53:39'),
(28, 'associate', 'cases', 'add-folder', '2020-12-30 15:53:39', '2020-12-30 15:53:39'),
(29, 'associate', 'cases', 'upload-files', '2020-12-30 15:53:39', '2020-12-30 15:53:39'),
(30, 'associate', 'cases', 'move-to', '2020-12-30 15:53:39', '2020-12-30 15:53:39'),
(31, 'associate', 'cases', 'add-to-starred', '2020-12-30 15:53:39', '2020-12-30 15:53:39'),
(32, 'associate', 'cases', 'view-documents', '2020-12-30 15:53:39', '2020-12-30 15:53:39'),
(33, 'associate', 'cases', 'download-file', '2020-12-30 15:53:40', '2020-12-30 15:53:40'),
(34, 'associate', 'cases', 'view-file', '2020-12-30 15:53:40', '2020-12-30 15:53:40'),
(35, 'associate', 'cases', 'chat-on-document', '2020-12-30 15:53:40', '2020-12-30 15:53:40'),
(36, 'associate', 'cases', 'case-chat', '2020-12-30 15:53:40', '2020-12-30 15:53:40'),
(37, 'associate', 'cases', 'general-chat', '2020-12-30 15:53:40', '2020-12-30 15:53:40'),
(38, 'associate', 'cases', 'view-cases', '2020-12-30 15:53:40', '2020-12-30 15:53:40'),
(39, 'associate', 'leads', 'edit-lead', '2020-12-30 15:53:40', '2020-12-30 15:53:40'),
(40, 'associate', 'leads', 'mark-as-client', '2020-12-30 15:53:40', '2020-12-30 15:53:40'),
(41, 'associate', 'leads', 'view-leads', '2020-12-30 15:53:40', '2020-12-30 15:53:40'),
(42, 'associate', 'leads', 'recommend-as-client', '2020-12-30 15:53:40', '2020-12-30 15:53:40'),
(43, 'associate', 'global-module', 'top-notifications', '2020-12-30 15:53:40', '2020-12-30 15:53:40'),
(44, 'telecaller', 'cases', 'case-documents', '2020-12-30 15:53:40', '2020-12-30 15:53:40'),
(45, 'telecaller', 'cases', 'add-folder', '2020-12-30 15:53:40', '2020-12-30 15:53:40'),
(46, 'telecaller', 'cases', 'upload-files', '2020-12-30 15:53:40', '2020-12-30 15:53:40'),
(47, 'telecaller', 'cases', 'add-to-starred', '2020-12-30 15:53:41', '2020-12-30 15:53:41'),
(48, 'telecaller', 'cases', 'view-documents', '2020-12-30 15:53:41', '2020-12-30 15:53:41'),
(49, 'telecaller', 'cases', 'download-file', '2020-12-30 15:53:41', '2020-12-30 15:53:41'),
(50, 'telecaller', 'cases', 'view-file', '2020-12-30 15:53:41', '2020-12-30 15:53:41'),
(51, 'telecaller', 'cases', 'chat-on-document', '2020-12-30 15:53:41', '2020-12-30 15:53:41'),
(52, 'telecaller', 'cases', 'case-chat', '2020-12-30 15:53:41', '2020-12-30 15:53:41'),
(53, 'telecaller', 'cases', 'general-chat', '2020-12-30 15:53:41', '2020-12-30 15:53:41'),
(54, 'telecaller', 'cases', 'view-cases', '2020-12-30 15:53:41', '2020-12-30 15:53:41'),
(55, 'telecaller', 'leads', 'edit-lead', '2020-12-30 15:53:41', '2020-12-30 15:53:41'),
(56, 'telecaller', 'leads', 'view-leads', '2020-12-30 15:53:41', '2020-12-30 15:53:41'),
(57, 'telecaller', 'leads', 'quick-lead', '2020-12-30 15:53:41', '2020-12-30 15:53:41'),
(58, 'telecaller', 'global-module', 'top-notifications', '2020-12-30 15:53:41', '2020-12-30 15:53:41'),
(59, 'employee', 'global-module', 'top-notifications', '2020-12-30 15:53:41', '2020-12-30 15:53:41');

-- --------------------------------------------------------

--
-- Table structure for table `service_documents`
--

DROP TABLE IF EXISTS `service_documents`;
CREATE TABLE `service_documents` (
  `id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `name` varchar(500) NOT NULL,
  `slug` varchar(500) NOT NULL,
  `unique_id` varchar(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `service_documents`
--

INSERT INTO `service_documents` (`id`, `service_id`, `name`, `slug`, `unique_id`, `created_at`, `updated_at`) VALUES
(2, 5, 'Extra', 'extra', '435091', '2020-11-10 15:08:06', '2020-11-18 10:46:32'),
(3, 7, 'Certificates', 'certificates', '249015', '2020-11-18 10:41:39', '2020-11-18 10:48:14');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `unique_id` bigint(20) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `country_code` varchar(10) DEFAULT NULL,
  `phone_no` varchar(200) DEFAULT NULL,
  `date_of_birth` varchar(20) DEFAULT NULL,
  `gender` varchar(100) DEFAULT NULL,
  `country_id` int(11) NOT NULL DEFAULT '0',
  `state_id` int(11) NOT NULL DEFAULT '0',
  `city_id` int(11) NOT NULL DEFAULT '0',
  `address` text,
  `zip_code` varchar(15) DEFAULT NULL,
  `languages_known` text,
  `role` varchar(100) NOT NULL,
  `is_active` int(11) NOT NULL DEFAULT '0',
  `is_verified` int(11) NOT NULL DEFAULT '0',
  `profile_image` varchar(255) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `unique_id`, `first_name`, `last_name`, `email`, `password`, `country_code`, `phone_no`, `date_of_birth`, `gender`, `country_id`, `state_id`, `city_id`, `address`, `zip_code`, `languages_known`, `role`, `is_active`, `is_verified`, `profile_image`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 8911642537, 'Fastzone', 'Services', 'fastzone@demo.com', '$2y$10$3h8x41CXdHtWdeb/JL5DUOmDygi5Pv5D0PJWVYvqwNVekrIpdcd6m', '+91', '7894563210', '16/07/2009', 'male', 38, 663, 10107, 'sfsfsdfsd', '123213', '[\"1\",\"2\"]', 'admin', 1, 1, '94675-avatar5.png', 0, '2020-11-03 17:25:48', '2021-01-22 17:08:04'),
(2, 7659124831, 'test', 'test', 'test@gmail.com', '$2y$10$B1J/6J4gFxQby9.FwA5Sae58766XPCpUMLXhT5dTzITo3ToNn5uwa', '+91', '12321321321', '31/12/2018', 'male', 38, 663, 10107, '321321', '123321', '[\"1\",\"2\"]', 'manager', 1, 1, '8399-user4-128x128.jpg', 1, '2020-11-12 14:14:49', '2021-01-22 16:44:30'),
(3, 7452316819, 'Daniel', 'Doe', 'daniel@demo.com', '$2y$10$XheaWPZpO6tnFUr0MySJf.J7m3iPX/Eh/aEIIHzjtHZehYD2wnxee', '+91', '123123213', '31/12/2019', 'male', 38, 663, 10095, '2311312', '12321', '[\"2\",\"3\"]', 'associate', 1, 1, NULL, 1, '2020-11-12 14:42:11', '2020-11-12 15:08:44'),
(4, 7136582914, 'Telecaller', 'User', 'telecaller@demo.com', '$2y$10$1VRSD3GFC/y/bMgM4ajxCOt8h/9sM5eiIS3K/XAXXxH.e4iULdySi', '+91', '1231231232132', '12/07/1995', 'male', 38, 663, 10107, '91,Liverpool Street Canada', '123456', '[\"1\",\"2\"]', 'telecaller', 1, 1, '25015-avatar5.png', 1, '2021-01-22 15:11:49', '2021-01-22 15:35:50');

-- --------------------------------------------------------

--
-- Table structure for table `verification_code`
--

DROP TABLE IF EXISTS `verification_code`;
CREATE TABLE `verification_code` (
  `id` int(11) NOT NULL,
  `verify_by` varchar(255) NOT NULL,
  `match_string` varchar(100) NOT NULL,
  `verify_code` varchar(255) NOT NULL,
  `expiry_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assessment_case`
--
ALTER TABLE `assessment_case`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `assign_leads`
--
ALTER TABLE `assign_leads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cases`
--
ALTER TABLE `cases`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `case_documents`
--
ALTER TABLE `case_documents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `case_folders`
--
ALTER TABLE `case_folders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `case_invoices`
--
ALTER TABLE `case_invoices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `case_invoice_items`
--
ALTER TABLE `case_invoice_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `case_teams`
--
ALTER TABLE `case_teams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chats`
--
ALTER TABLE `chats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chat_read`
--
ALTER TABLE `chat_read`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `documents`
--
ALTER TABLE `documents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `document_chats`
--
ALTER TABLE `document_chats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `domain_details`
--
ALTER TABLE `domain_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leads`
--
ALTER TABLE `leads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notification_data`
--
ALTER TABLE `notification_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notification_read`
--
ALTER TABLE `notification_read`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `professional_details`
--
ALTER TABLE `professional_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `professional_services`
--
ALTER TABLE `professional_services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `professional_settings`
--
ALTER TABLE `professional_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reminder_notes`
--
ALTER TABLE `reminder_notes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role_privileges`
--
ALTER TABLE `role_privileges`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service_documents`
--
ALTER TABLE `service_documents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `verification_code`
--
ALTER TABLE `verification_code`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assessment_case`
--
ALTER TABLE `assessment_case`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `assign_leads`
--
ALTER TABLE `assign_leads`
  MODIFY `id` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
--
-- AUTO_INCREMENT for table `cases`
--
ALTER TABLE `cases`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `case_documents`
--
ALTER TABLE `case_documents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;
--
-- AUTO_INCREMENT for table `case_folders`
--
ALTER TABLE `case_folders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `case_invoices`
--
ALTER TABLE `case_invoices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `case_invoice_items`
--
ALTER TABLE `case_invoice_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `case_teams`
--
ALTER TABLE `case_teams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `chats`
--
ALTER TABLE `chats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `chat_read`
--
ALTER TABLE `chat_read`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `documents`
--
ALTER TABLE `documents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=114;
--
-- AUTO_INCREMENT for table `document_chats`
--
ALTER TABLE `document_chats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;
--
-- AUTO_INCREMENT for table `domain_details`
--
ALTER TABLE `domain_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `leads`
--
ALTER TABLE `leads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `notification_data`
--
ALTER TABLE `notification_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;
--
-- AUTO_INCREMENT for table `notification_read`
--
ALTER TABLE `notification_read`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `professional_details`
--
ALTER TABLE `professional_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `professional_services`
--
ALTER TABLE `professional_services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `professional_settings`
--
ALTER TABLE `professional_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `reminder_notes`
--
ALTER TABLE `reminder_notes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `role_privileges`
--
ALTER TABLE `role_privileges`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;
--
-- AUTO_INCREMENT for table `service_documents`
--
ALTER TABLE `service_documents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `verification_code`
--
ALTER TABLE `verification_code`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
