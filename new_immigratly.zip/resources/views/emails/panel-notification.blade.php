@extends('emails.email-master')

@section('content')
<h1>Testing</h1>
@endsection